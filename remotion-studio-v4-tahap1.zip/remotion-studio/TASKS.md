# TASKS.md

> Status pekerjaan. Agen WAJIB memperbarui file ini di akhir setiap tugas.
> Status: `[ ]` belum, `[~]` sedang, `[x]` selesai, `[!]` terblokir (tulis alasannya).

## Milestone saat ini: **M0 Fondasi**

## Dokumen aturan (dibuat lewat chat, lalu disalin ke repo)

### Batch 1: Fondasi
- [x] AGENTS.md, CLAUDE.md
- [x] PROJECT.md, TASKS.md, DECISIONS.md
- [x] docs/ARCHITECTURE.md
- [x] docs/REMOTION_RULES.md
- [x] docs/STYLE_GUIDE.md
- [x] docs/MOTION_SYSTEM.md
- [x] docs/SIMPLE_AND_FUN.md (baru di v2)
- [x] Revisi v2: palet kuning/putih/navy, simpel dan seru (D-014 sampai D-030)

### Batch 2: Aset dan lisensi
- [ ] docs/ASSET_SOURCING.md
- [ ] LICENSES.md
- [ ] docs/ASSET_PIPELINE.md
- [ ] assets.schema.json (+ assets.json kosong)

### Batch 3: Alur kerja
- [ ] templates/BRIEF.md, SCRIPT.md, STORYBOARD.md, SHOTLIST.md
- [ ] templates/SCENE_SPEC.md + schemas/ (Zod) + SCHEMA_CHANGELOG.md
- [ ] docs/QA_CHECKLIST.md, RUBRIC.md, VISUAL_REVIEW_PROMPT.md
- [ ] docs/AUDIO_AND_VOICE.md, CAPTIONS.md
- [ ] docs/CAMERA_RULES.md, TRANSITIONS.md, ACCESSIBILITY.md

### Batch 4: Genre
- [ ] genres/EDUCATION.md
- [ ] genres/ADVERTISING.md (+ CLAIMS_POLICY.md)
- [ ] genres/ENTERTAINMENT.md

### Batch 5: Peran dan skill
- [ ] agents/*.md (7 peran)
- [ ] skills/*/SKILL.md (adegan dari spec, bersihkan SVG, ambil aset, review frame)
- [ ] PROMPTS.md, COMPONENT_CATALOG.md, LESSONS.md, COST_BUDGET.md

### Batch 0: Mesin pipeline (pola OpenMontage: manifest, checkpoint, gerbang)
- [x] pipeline.json (manifest tahap), studio.config.json
- [x] scripts/lib: fsx, manifest, validators, decisions, checkpoint
- [x] scripts/pipeline.mjs (CLI) + 11 tes lulus (`node --test scripts/test/pipeline.test.mjs`)
- [x] templates/BRIEF.md
- [ ] Validator lanjutan (storyboard, audio/timing.json, scenes, assets, qa/report.json)
- [ ] Skrip preflight (Node, ffmpeg, versi Remotion) dan penegak anggaran

## Peta jalan (lulus jika...)

| Milestone | Isi | Lulus jika | Status |
|---|---|---|---|
| M0 Fondasi | Repo, Remotion versi terkunci, skill resmi, lint | Video "hello world" dirender otomatis lewat CI | [ ] |
| M1 Design system | Token (warna, tipografi, motif), 10 primitif termasuk `Blobby` | Satu style frame edukasi disetujui dari contact sheet 12 seed | [ ] |
| M2 Spec dan schema | Format spec adegan + validator | AI menghasilkan spec valid tanpa perbaikan manual | [ ] |
| M3 Pustaka gerak | 15 gerak siap pakai, kamera, transisi | Adegan 10 detik skor gerak di atas ambang | [ ] |
| M4 Aset | Pipeline, manifes, 100 aset awal disetujui | Aset baru masuk tanpa campur tangan manual | [ ] |
| M5 Audio | Narasi, penanda kata, caption, ketukan | Sinkronisasi akurat dalam toleransi frame | [ ] |
| M6 QA otomatis | Tiga lapis verifikasi + golden stills | Regresi terdeteksi otomatis | [ ] |
| M7 Pilot tiga genre | Satu video per genre | Skor rubrik di atas ambang + evaluasi manusia positif | [ ] |
| M8 Skala | Batch, varian format, dasbor biaya | Satu brief menjadi tiga format tanpa kerja ulang | [ ] |

Setiap milestone diakhiri retrospektif; temuannya masuk ke `LESSONS.md` dan memperbarui aturan.

## Tugas aktif: M0 Fondasi

- [ ] **M0.1** Inisialisasi repo (monorepo TypeScript ketat; struktur di `docs/ARCHITECTURE.md` bagian 2)
- [ ] **M0.2** Buat proyek Remotion; kunci versi persis di semua paket `remotion` dan `@remotion/*`
- [ ] **M0.3** Pasang skill resmi Remotion; verifikasi `.claude/skills` menunjuk ke `.agents/skills`
- [ ] **M0.4** Pasang `@remotion/eslint-plugin`; tambah aturan proyek (larangan CSS animation, `Math.random`)
- [ ] **M0.5** Skrip `npm run check` (typecheck + lint + validasi schema)
- [ ] **M0.6** Komposisi "hello world" 3 detik memakai token dan satu spring
- [ ] **M0.7** CI: check, render still, render video kecil
- [ ] **M0.8** **Verifikasi API**: Zod/props, caption, analisis audio, transisi terhadap versi terkunci; catat hasil di `DECISIONS.md`
- [ ] **M0.9** Jawab pertanyaan terbuka Q1 sampai Q7 di `PROJECT.md`

## Terblokir / menunggu keputusan

_(kosong)_
