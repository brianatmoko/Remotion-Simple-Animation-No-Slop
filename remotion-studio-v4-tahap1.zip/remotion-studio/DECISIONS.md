# DECISIONS.md

> Catatan keputusan beserta alasannya, agar AI dan manusia tidak mengulang atau menyalahi keputusan lama.
> Catatan penomoran: D-021 sampai D-023, D-025, dan D-026 dicadangkan untuk keputusan berikutnya.
> Aturan: keputusan tidak dihapus. Bila berubah, tulis keputusan baru yang `menggantikan` yang lama.
> Status: `diterima` | `usulan` | `perlu-verifikasi` | `digantikan`

## Templat

```
### D-XXX Judul singkat
- Status:
- Tanggal:
- Konteks: masalah atau pilihan yang dihadapi
- Keputusan: apa yang dipilih
- Alasan: kenapa
- Konsekuensi: apa yang jadi lebih mudah/sulit
- Ditinjau ulang pada: milestone atau kondisi
```

---

### D-001 Adegan didefinisikan sebagai spec terstruktur
- Status: diterima
- Konteks: AI yang menulis kode video bebas menghasilkan keluaran tak seragam dan sulit direvisi.
- Keputusan: AI menulis spec adegan (JSON/YAML), divalidasi schema Zod; komponen teruji yang merender.
- Alasan: struktur salah ditolak sebelum render; revisi = ubah data; satu spec bisa diturunkan ke banyak format; diff antar versi mudah dibaca.
- Konsekuensi: butuh investasi awal di schema dan pustaka komponen (M2, M3).
- Ditinjau ulang pada: M2

### D-002 Pipeline sembilan tahap dengan gerbang
- Status: diterima
- Keputusan: Brief, Skrip, Storyboard, Audio, Spec, Aset, Build, Verifikasi, Render. Tiap tahap punya pemilik, keluaran, dan gerbang. Detail di `docs/ARCHITECTURE.md`.
- Alasan: kesalahan kecil tidak menumpuk sampai render akhir.

### D-003 Audio-first
- Status: diterima
- Keputusan: audio dikunci sebelum spec adegan; animasi mengikuti audio, bukan sebaliknya.
- Alasan: mengubah audio setelah animasi jadi merusak sinkronisasi dan memaksa kerja ulang.

### D-004 Persetujuan manusia hanya di tiga titik
- Status: diterima
- Keputusan: storyboard, style frame, hasil akhir.
- Alasan: menjaga kendali kreatif tanpa memperlambat tahap teknis.

### D-005 Loop perbaikan maksimal 3 putaran per adegan
- Status: diterima
- Keputusan: setelah 3 putaran, serahkan ke manusia dengan ringkasan masalah.
- Alasan: mencegah putaran tak berujung dan biaya membengkak.
- Ditinjau ulang pada: M7 (sesuaikan dengan data biaya nyata)

### D-006 Kebijakan lisensi aset
- Status: diterima
- Keputusan: prioritas sumber: buatan sendiri/prosedural, CC0 dan domain publik, MIT/Apache/OFL, CC BY. `CC BY-NC` dan lisensi tidak jelas ditolak otomatis. Iklan: tanpa logo/merek tanpa izin, tanpa wajah yang bisa dikenali.
- Alasan: risiko hukum terbesar ada di iklan; aturan paling ketat dijadikan default.

### D-007 Format kanvas dan fps dasar
- Status: usulan
- Keputusan (usulan): kanvas dasar 1920x1080 (16:9), 30 fps. Varian 9:16 (1080x1920) dan 1:1 (1080x1080) diturunkan dari spec yang sama lewat aturan tata letak, bukan dengan menggambar ulang.
- Alasan: 30 fps cukup untuk gaya vektor dan menghemat waktu render dibanding 60 fps; semua token durasi dinyatakan dalam frame pada 30 fps.
- Konsekuensi: bila fps diubah, seluruh token waktu harus dihitung ulang (satu tempat: `tokens/motion.ts`).
- Ditinjau ulang pada: M1 (saat style frame disetujui)

### D-008 Kunci versi Remotion
- Status: diterima
- Keputusan: semua paket `remotion` dan `@remotion/*` di versi persis sama, tanpa `^` atau `~`. Upgrade hanya lewat keputusan baru.
- Alasan: versi paket Remotion yang tidak sama menimbulkan galat; AI cenderung memakai API dari versi lain bila versi tidak dikunci.

### D-009 Skill resmi Remotion sebagai fondasi
- Status: diterima
- Keputusan: pasang skill resmi Remotion; tambahkan skill proyek di atasnya (bold vector, spec adegan, aset, QA). Skill proyek tidak menyalin isi skill resmi, hanya menambah.
- Alasan: praktik terbaik dari pembuat Remotion; mengurangi duplikasi.

### D-010 Validasi spec dengan Zod
- Status: perlu-verifikasi
- Keputusan (usulan): Zod untuk schema spec, terintegrasi dengan input props komposisi Remotion.
- Verifikasi: M0.8, cek integrasi dan paket pendukung terhadap versi terkunci.

### D-011 Rubrik 100 poin dengan bobot per genre
- Status: diterima
- Keputusan: enam dimensi (gerak 25, komposisi 20, gaya 15, tipografi 15, audio 15, pesan 10) sebagai bobot dasar; digeser per genre. Ambang lolos ditetapkan di `RUBRIC.md` dan dikalibrasi di M7.

### D-012 Struktur monorepo
- Status: diterima
- Keputusan: lihat `docs/ARCHITECTURE.md` bagian 2. Paket: `components`, `schemas`, `tokens`, `assets-tools`; aplikasi: `studio`.
- Alasan: pemisahan jelas antara data (schema, token), tampilan (komponen), dan alat (aset).

### D-013 Bahasa dokumentasi
- Status: diterima
- Keputusan: dokumen dan laporan agen dalam Bahasa Indonesia; identifier kode dan nama berkas dalam Inggris.

### D-014 Docx rencana lama tidak berlaku untuk angka
- Status: diterima
- Tanggal: 2026-10-07
- Konteks: docx rencana awal memuat palet, ukuran, dan token yang berbeda dari repo.
- Keputusan: untuk angka apa pun (warna, ukuran, durasi, batas), repo ini yang berlaku. Docx hanya latar belakang. Hitungan elemen dipisah: **elemen utama** (3 sampai 5 per layar) dan **elemen terlihat** (anggaran per genre); keduanya bukan konflik.
- Alasan: satu sumber kebenaran; menghindari dua angka untuk hal yang sama.

### D-015 Palet merek ditetapkan pemilik
- Status: diterima
- Tanggal: 2026-10-07
- Keputusan: tiga keluarga warna: **kuning** (primer, `sun500` #FFB800), **putih** (ikon, SVG, kartu), **navy** (aksen: kontur, teks, bayangan). Latar penuh hanya dari empat langkah kuning; navy dan putih tidak pernah jadi latar penuh. Ikon putih wajib berkontur navy.
- Alasan: identitas merek cerah; kontras dihitung (putih di atas kuning hanya 1,4 sampai 2,3:1, jadi dilarang untuk teks).
- Konsekuensi: palet v1 (ink, paper, primary, coral, mint, sky) dihapus. Rincian di `docs/STYLE_GUIDE.md` bagian 4.
- Ditinjau ulang pada: M1 (style frame)

### D-016 Skala tipografi menurut konteks tonton
- Status: usulan
- Keputusan: `brief.md` memuat `viewing: phone | large`; token `type.*` memilih skala. 16:9 yang ditonton di ponsel memakai skala lebih besar (label minimum ≈60 px pada 1080p).
- Alasan: video 16:9 di ponsel hanya tampil ≈0,2x; 32 px menjadi terlalu kecil.
- Ditinjau ulang pada: M1

### D-017 Durasi adegan mengikuti kalimat narasi
- Status: diterima
- Keputusan: durasi adegan ditentukan oleh narasi (kalimat/frasa), bukan oleh tabel durasi. Tabel kerangka hanya titik awal.
- Alasan: audio-first (D-003); menghindari narasi terpotong atau jeda kosong.

### D-018 Prioritas elemen untuk turunan 9:16
- Status: usulan
- Keputusan: tiap elemen spec punya `priority` (`must` | `should` | `optional`). Tinggi layak 9:16 = 1250 px. `optional` dibuang dari prioritas terendah; `must` tidak pernah dibuang otomatis, kegagalan dilaporkan Lapis 1.
- Ditinjau ulang pada: M2

### D-019 Motif latar datar berkontras rendah
- Status: usulan
- Keputusan: satu `motif.*` per adegan dari langkah kuning lain, rasio kontras terhadap latar 1,1 sampai 1,6:1; tanpa gradien.
- Alasan: latar hidup tanpa menambah warna dan tanpa menyaingi hero.
- Ditinjau ulang pada: M1

### D-020 Pesan inti terbaca tanpa suara
- Status: diterima
- Keputusan: hook dan pesan inti harus dapat dipahami tanpa audio (teks/caption/visual). Diuji dengan tonton bisu (`SIMPLE_AND_FUN.md` bagian 8).
- Alasan: banyak penonton menonton tanpa suara.

### D-024 Uji karakter AI sebelum rig berlapis
- Status: diterima
- Keputusan: rig karakter bersendi baru dipakai setelah uji karakter AI lulus, dijadwalkan sebelum M4. Sampai itu, `lipSync` dan rig ditunda.
- Alasan: rig adalah komponen termahal dan paling rawan tidak konsisten.

### D-027 Seed visual dari contact sheet 12 seed
- Status: diterima
- Keputusan: Art Director menyajikan satu gambar berisi 12 seed; yang dipilih dan ditolak dicatat di `projects/<slug>/seeds.md` beserta alasan. Pemilik boleh veto.
- Alasan: pilihan terlihat dan terdokumentasi; mengurangi bolak-balik di style frame.

### D-028 Pilot edukasi tanpa rig karakter
- Status: diterima
- Keputusan: rasa karakter lewat *shape acting* (`Blobby`: blob dengan mata titik, kedip, squash dan stretch). Berlaku untuk pilot edukasi.
- Alasan: lebih simpel dan murah; selaras dengan tujuan simpel dan seru.

### D-029 Manusia menang atas rubrik
- Status: diterima
- Keputusan: bila skor rubrik lolos tetapi penonton uji bosan, penilaian manusia yang dipakai dan kasusnya dicatat di `LESSONS.md`. Kriteria "daya tarik" masuk `RUBRIC.md` (Batch 3).

### D-030 Simpel dan seru sebagai prinsip utama
- Status: diterima
- Tanggal: 2026-10-07
- Konteks: pemilik ingin video simpel, seru, dan tidak membosankan.
- Keputusan: `docs/SIMPLE_AND_FUN.md` menjadi acuan wajib untuk skrip, storyboard, dan spec. Batas kata diperketat (judul ≤ 6 kata, isi ≤ 8 kata per layar). Resep adegan tiga ketukan; hook 3 detik; anggaran seru; ritme edukasi 0,6 sampai 1,2 perubahan visual per detik.
- Konsekuensi: menggantikan batas v1 (8 dan 12 kata; 0,4 sampai 1,0 perubahan per detik).
- Ditinjau ulang pada: M7 (pilot, dengan penonton uji)

---

## Verifikasi M0.8 (diisi saat M0)

| Hal yang diverifikasi | Versi Remotion | Hasil | Tanggal |
|---|---|---|---|
| Integrasi Zod dengan props komposisi | | | |
| Paket caption dan format data | | | |
| Analisis audio (waveform, visualisasi) | | | |
| Paket transisi antar adegan | | | |
| Lisensi Remotion untuk kasus komersial kita | | | |
