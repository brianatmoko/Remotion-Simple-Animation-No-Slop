# CLAUDE.md

Semua aturan proyek ada di satu tempat agar agen mana pun membaca hal yang sama.

@AGENTS.md

## Tambahan khusus Claude Code

- Skill resmi Remotion dipasang di `.agents/skills` (`.claude/skills` adalah symlink). Gunakan sebagai fondasi; skill milik proyek ada di `skills/`.
- Sebelum memakai API Remotion yang tidak umum, periksa dokumentasi sesuai versi yang dikunci di `package.json`.
- Jalankan `npm run check` (typecheck + lint + validasi schema) sebelum menyatakan tugas selesai.
