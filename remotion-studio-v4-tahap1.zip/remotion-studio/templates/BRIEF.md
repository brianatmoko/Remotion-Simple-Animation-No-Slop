---
genre: [ISI]            # education | advertising | entertainment
viewing: [ISI]          # phone | large
language: id            # id | en | bilingual
audience: [ISI]
duration_seconds: [ISI]
pulse_seconds: 3        # jeda maksimum antar perpindahan objek (<= 3)
formats: [9:16]         # 16:9 | 9:16 | 1:1
hook_pattern: [ISI]     # pertanyaan | angka | salah-kaprah | perbandingan | teka-teki
core_message: [ISI]
claims: none            # none | sourced
voice_plan: tts         # tts | recorded | none
music_plan: none        # none | stock-licensed | self-made
render_runtime: remotion
---

# Brief

Satu kalimat pesan inti, siapa penonton, dan apa yang harus mereka ingat.
