# PROJECT.md

> Tujuan, ruang lingkup, dan batasan. Dibaca agen saat butuh konteks "kenapa". Bagian bertanda **[ISI]** perlu dijawab pemilik proyek.

## 1. Tujuan

Membangun sistem yang membuat video animasi **bold vector cerah** yang **simpel dan seru** (tidak membosankan) dan berkualitas standar industri secara konsisten, dengan AI sebagai pelaksana dan manusia sebagai pengarah di tiga titik persetujuan.

Keberhasilan diukur, bukan dirasakan: setiap video dinilai dengan rubrik 100 poin (`RUBRIC.md`) dan baru lolos bila di atas ambang.

## 2. Tiga genre

| | Edukasi | Iklan | Hiburan |
|---|---|---|---|
| Tujuan | Audiens paham satu konsep | Audiens bertindak (CTA) | Audiens terhibur dan menonton ulang |
| Struktur | Hook, masalah, penjelasan bertahap, contoh, rangkuman | Hook 3 detik, masalah, solusi, bukti, CTA | Premis, eskalasi, kejutan, punchline/loop |
| Tempo | Tenang | Cepat dan padat | Berirama, timing komedi |
| Format utama | 16:9 (potongan 9:16) | 16:9, 9:16, 1:1 sekaligus | 9:16 (sekunder 16:9) |
| Durasi pilot | 30 sampai 60 detik | 15 sampai 30 detik (pilot 30 detik) | 30 sampai 60 detik |
| Metrik | Kejelasan, retensi | Kekuatan hook, kejelasan CTA | Kebaruan, kemudahan ditonton ulang |

Pilot pertama: **edukasi**, 36 detik, 8 adegan (`docs/SIMPLE_AND_FUN.md` bagian 7), tanpa rig karakter (D-028).

Fondasi bersama: satu design system, satu pustaka komponen, satu format spec. Yang berbeda: struktur, tempo, ukuran layar, bobot rubrik.

## 3. Audiens

- **[ISI]** Audiens utama per genre (usia, bahasa, konteks tontonan, platform).
- Konteks tonton (`viewing: phone | large`) ditulis di tiap `brief.md` dan menentukan skala teks (`STYLE_GUIDE.md` bagian 7).
- Bahasa konten default: **[ISI]** (Indonesia / Inggris / dwibahasa).
- Aksesibilitas adalah syarat dasar: caption, kontras, batas kedipan (`ACCESSIBILITY.md`).

## 4. Batasan

**Teknis**
- Remotion (React + TypeScript ketat), versi dikunci.
- Output: MP4 (H.264) sebagai default; caption sebagai berkas terpisah dan/atau dibakar ke video.
- Kanvas dasar 1920x1080, 30 fps (lihat `DECISIONS.md` D-007).

**Hukum dan lisensi**
- Hanya aset berlisensi jelas (`LICENSES.md`). `CC BY-NC` dilarang untuk iklan.
- Tanpa logo/merek dagang tanpa izin. Tanpa wajah orang yang bisa dikenali di iklan.
- Lisensi Remotion untuk penggunaan komersial: **periksa syarat resmi terbaru** sebelum iklan atau layanan berbayar. **[ISI]** status lisensi.

**Sumber daya**
- Anggaran token dan waktu per video dicatat di `COST_BUDGET.md`. Batas awal: **[ISI]**.
- Lingkungan eksekusi: agen berbasis terminal (mis. Claude Code) di komputer sendiri. Pengambilan aset butuh akses jaringan.

## 5. Di luar lingkup (untuk saat ini)

- Animasi 3D dan video live-action.
- Pengeditan video mentah (footage) sebagai pekerjaan utama.
- Pengisi suara dengan kloning suara orang nyata.
- Publikasi otomatis ke platform.

## 6. Prinsip rancangan

1. Sistem, bukan prompt: konsistensi datang dari aturan, komponen, dan pengecekan otomatis.
2. Komposisi dari komponen teruji, bukan menggambar dari nol.
3. Periksa-dan-perbaiki dengan batas putaran.
4. Audio-first: animasi mengikuti audio.
5. Semua keputusan tertulis; agen mana pun membaca aturan yang sama.
6. Satu spec, banyak format.
7. Simpel dan seru: sedikit elemen, sedikit kata, gerak yang punya rasa (`docs/SIMPLE_AND_FUN.md`, D-030).

## 7. Pertanyaan terbuka

| # | Pertanyaan | Pemilik | Status |
|---|---|---|---|
| Q1 | Audiens dan bahasa utama per genre | Pemilik proyek | terbuka |
| Q2 | Status lisensi Remotion untuk penggunaan komersial | Pemilik proyek | terbuka |
| Q3 | Anggaran token/waktu per video | Pemilik proyek | terbuka |
| Q4 | Sumber narasi: TTS (penyedia apa) atau rekaman | Pemilik proyek | terbuka |
| Q5 | Merek/klien nyata atau fiktif untuk pilot iklan | Pemilik proyek | terbuka |
| Q6 | Konteks tonton utama: ponsel atau layar besar (menentukan skala teks) | Pemilik proyek | terbuka |
| Q7 | Topik pilot edukasi (satu konsep) | Pemilik proyek | terbuka |
