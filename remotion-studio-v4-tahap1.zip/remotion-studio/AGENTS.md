# AGENTS.md

> Pintu masuk untuk SEMUA agen AI. Dokumen ini sengaja ringkas. Ia menunjuk ke dokumen lain; jangan memuat semuanya sekaligus.

## 1. Apa proyek ini

Sistem produksi video animasi **bold vector cerah (kuning, putih, navy)** berbasis Remotion untuk tiga genre: **edukasi, iklan, hiburan**. Video harus **simpel dan seru**. Video adalah kode. Kualitas dijaga oleh token desain, komponen teruji, spec adegan terstruktur, dan gerbang QA otomatis. Detail: `PROJECT.md`.

## 2. Urutan baca (wajib, berurutan)

1. File ini.
2. `TASKS.md`: cari tugas aktif dan milestone saat ini.
3. `DECISIONS.md`: pastikan pekerjaanmu tidak menyalahi keputusan lama.
4. Dokumen sesuai tahap pipeline (lihat tabel di bagian 5). Muat hanya yang dibutuhkan.

## 3. Aturan keras (tidak boleh dilanggar)

1. **Dilarang CSS animation/transition**, kelas `animate-*` Tailwind, dan animasi berbasis `setState`/`setTimeout`. Semua gerak dihitung dari nomor frame. Lihat `docs/REMOTION_RULES.md`.
2. **Jangan menggambar dari nol** bila komponen ada. Cari di `COMPONENT_CATALOG.md` dulu. Komponen baru hanya lewat prosedur (usulan, tes, masuk pustaka).
3. **Warna, ukuran, durasi, easing hanya dari token.** Tidak ada hex, angka frame, atau kurva easing mentah di kode adegan.
4. **Adegan = spec JSON tervalidasi Zod**, bukan kode bebas. Spec salah ditolak sebelum render.
5. **Versi paket Remotion dikunci** (semua paket `remotion` dan `@remotion/*` di versi persis sama, tanpa `^`). Untuk API yang tidak umum, baca dokumentasi versi terkunci sebelum memakainya. Jangan menebak API.
6. **Tidak ada nilai acak tak-deterministik.** Pakai `random(seed)` dari Remotion, bukan `Math.random()`. Render ulang harus menghasilkan video identik.
7. **Aset hanya dari `assets.json` berstatus `approved`.** Lisensi tidak jelas = ditolak. `CC BY-NC` dilarang untuk iklan. Tanpa logo/merek dagang tanpa izin tertulis.
8. **Loop perbaikan maksimal 3 putaran per adegan**, lalu serahkan ke manusia dengan ringkasan masalah. Jangan berputar tanpa akhir.
9. **Jangan mengubah file di luar lingkup tugasmu.** Perubahan token, schema, atau komponen bersama wajib dicatat di `DECISIONS.md`.
10. **Jangan mengarang fakta.** Klaim iklan harus punya sumber di brief. Lihat `CLAIMS_POLICY.md` (dibuat di tahap genre).
11. **Latar selalu kuning.** Navy atau putih tidak pernah jadi latar penuh. Ikon dan SVG putih wajib berkontur navy; teks putih hanya di atas chip navy. Lihat `docs/STYLE_GUIDE.md` bagian 4.
12. **Simpel dan seru.** Satu ide per video, satu hero per adegan, judul ≤ 6 kata, isi ≤ 8 kata per layar, pesan terbaca tanpa suara. Lihat `docs/SIMPLE_AND_FUN.md`.

## 4. Peran

| Peran | Tanggung jawab | Berkas |
|---|---|---|
| Sutradara | Alur, cerita, persetujuan skrip/storyboard | `agents/DIRECTOR.md` |
| Penulis Skrip | Skrip dengan penanda waktu | `agents/SCRIPTWRITER.md` |
| Art Director | Konsistensi gaya, contact sheet seed, style frame | `agents/ART_DIRECTOR.md` |
| Motion Designer | Menulis spec adegan dan komponen | `agents/MOTION_DESIGNER.md` |
| Asset Curator | Cari, periksa lisensi, bersihkan aset | `agents/ASSET_CURATOR.md` |
| Audio Producer | Narasi, musik, ketukan, loudness | `agents/AUDIO_PRODUCER.md` |
| QA Reviewer | Menilai render dengan rubrik | `agents/QA_REVIEWER.md` |

Satu sesi = satu peran. Sebutkan perannya di awal pekerjaan.
(Berkas peran dibuat di tahap "Peran agen dan skill"; sebelum ada, ikuti tabel ini.)

## 5. Peta dokumen per tahap pipeline

| # | Tahap | Muat dokumen |
|---|---|---|
| 1 | Brief | `templates/BRIEF.md`, `genres/<genre>.md` |
| 2 | Skrip | `templates/SCRIPT.md`, `genres/<genre>.md`, `docs/SIMPLE_AND_FUN.md` |
| 3 | Storyboard | `templates/STORYBOARD.md`, `docs/STYLE_GUIDE.md`, `docs/SIMPLE_AND_FUN.md` |
| 4 | Audio | `docs/AUDIO_AND_VOICE.md`, `CAPTIONS.md` |
| 5 | Spec adegan | `templates/SCENE_SPEC.md`, `schemas/`, `docs/MOTION_SYSTEM.md`, `docs/SIMPLE_AND_FUN.md` |
| 6 | Aset | `docs/ASSET_SOURCING.md`, `LICENSES.md`, `assets.json` |
| 7 | Build | `docs/REMOTION_RULES.md`, `COMPONENT_CATALOG.md`, `docs/STYLE_GUIDE.md` |
| 8 | Verifikasi | `docs/QA_CHECKLIST.md`, `RUBRIC.md` |
| 9 | Render & ekspor | `docs/ARCHITECTURE.md` (bagian render) |

Dokumen yang belum ada ditandai di `TASKS.md` dengan status `belum dibuat`. Jangan mengarang isinya; buat tugas untuk membuatnya.

## 6. Titik persetujuan manusia

Berhenti dan minta persetujuan di tiga titik saja:
1. **Storyboard** (tahap 3)
2. **Style frame** (awal tahap 7; seed dipilih dari contact sheet 12 seed, D-027)
3. **Hasil akhir** (tahap 9)

Di luar itu, kerja otomatis selama gerbang tahap lolos.

## 7. Definisi selesai (Definition of Done)

Sebuah tugas selesai hanya jika **semua** benar:
- [ ] Typecheck dan lint lolos tanpa peringatan baru.
- [ ] Spec lolos validasi schema.
- [ ] Hanya token dan komponen katalog yang dipakai (atau komponen baru sudah lewat prosedur).
- [ ] Gerbang QA tahap terkait lolos (`docs/QA_CHECKLIST.md`).
- [ ] `TASKS.md` diperbarui.
- [ ] Keputusan non-sepele dicatat di `DECISIONS.md`; kesalahan berulang dicatat di `LESSONS.md`.

## 8. Cara berkomunikasi

- Bahasa dokumen dan laporan: **Bahasa Indonesia**. Identifier kode dan nama file: Inggris.
- Laporan singkat: apa yang diubah, gerbang mana yang lolos/gagal, apa langkah berikutnya.
- Bila instruksi bertabrakan dengan dokumen ini, tanyakan ke manusia. Jangan memilih diam-diam.
