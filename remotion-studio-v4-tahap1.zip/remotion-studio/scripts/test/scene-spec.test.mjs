import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { validateScene, validateRhythm, resolveStarts, loadTokens, countWords } from "../lib/scene-spec.mjs";
import { validateBriefFrontmatter } from "../lib/validators.mjs";

const SRC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const T = loadTokens();
const brief = { duration_seconds: 12 };

const mk = (id, recipe, layout) => ({
  schemaVersion: "1.1.0", id, genre: "education", durationFrames: 180,
  intent: { purpose: "explain", message: "AI belajar dari kebiasaan", hero: "hero", metaphor: "kartu" },
  layout: { type: layout, safeZone: "default" },
  background: { recipe, token: T.recipes[recipe], motif: "motif.dots" },
  keyframes: { start: { description: "a" }, build: { description: "b" }, hero: { description: "c" }, payoff: { description: "d" } },
  camera: { purpose: "emphasize", move: "none" },
  elements: [
    { id: "hero", component: "Card", role: "hero", priority: "must" },
    { id: "cap", component: "Chip", role: "secondary", priority: "must", content: { text: "AI belajar dari kebiasaanmu." }, bounds: { x: 0.14, y: 0.66, w: 0.72, h: 0.1 } },
    { id: "bg", component: "Rays", role: "background", priority: "optional", bleed: true },
  ],
  choreography: [
    { id: "c1", target: "hero", motion: "pop", pulse: "enter", motionPurpose: "introduce", start: 0, duration: "base", spring: "spring.snappy", wow: true },
    { id: "c2", target: "cap", motion: "fadeUp", pulse: "reveal", motionPurpose: "reveal", start: 60, duration: "base", ease: "ease.out" },
    { id: "c3", target: "hero", motion: "slideIn", pulse: "move", motionPurpose: "explain", start: 120, duration: "base", ease: "ease.out" },
    { id: "m1", target: "bg", motion: "breathe", micro: true, start: 0, duration: "epic", ease: "ease.inOut" },
  ],
  transitionOut: { type: "wipe", from: "kartu", action: "kartu bergeser keluar", to: "kartu baru" },
  audio: { narration: "x" },
});
const video = () => [mk("01-a", "terang-klasik", "center-focus"), mk("02-b", "krim-tenang", "diagonal")];
const errs = (s) => validateScene(s).errors;

test("fixture valid: spec dan ritme lolos, jeda maks 2 dtk", () => {
  for (const s of video()) assert.deepEqual(errs(s), [], s.id);
  const r = validateRhythm(video(), { brief });
  assert.deepEqual(r.errors, []);
  assert.equal(r.stats.totalSeconds, 12);
  assert.ok(r.stats.maxGapSeconds <= 3);
});

test("jeda > 3 dtk ditolak", () => {
  const v = video(); v[1].choreography = v[1].choreography.filter((c) => c.id !== "c2" && c.id !== "c3");
  assert.ok(validateRhythm(v, { brief }).errors.some((e) => e.startsWith("DENYUT")));
});

test("hook diam 6 frame pertama ditolak", () => {
  const v = video(); v[0].choreography[0].start = 20;
  assert.ok(validateRhythm(v, { brief }).errors.some((e) => e.startsWith("HOOK")));
});

test("durasi menyimpang dari brief, resep latar sama berurutan ditolak", () => {
  assert.ok(validateRhythm(video(), { brief: { duration_seconds: 20 } }).errors.some((e) => /DURASI/.test(e)));
  const v = video(); v[1].background = { ...v[0].background };
  assert.ok(validateRhythm(v, { brief }).errors.some((e) => /berurutan/.test(e)));
});

test("micro tidak dihitung sebagai denyut", () => {
  const v = video(); v[0].choreography.push({ id: "m2", target: "bg", motion: "breathe", micro: true, start: 90, duration: "epic" });
  assert.equal(validateRhythm(v, { brief }).stats.pulses, validateRhythm(video(), { brief }).stats.pulses);
});

test("hero: tepat satu, intent.hero = id hero, hero wajib punya denyut", () => {
  const a = video()[0]; a.intent.hero = "cap";
  assert.ok(errs(a).some((e) => /intent\.hero/.test(e)));
  const b = video()[0]; b.elements[1].role = "hero";
  assert.ok(errs(b).some((e) => /lebih dari satu hero/.test(e)));
  const c = video()[0]; c.choreography = c.choreography.filter((x) => x.target !== "hero");
  assert.ok(errs(c).some((e) => /hero tanpa denyut/.test(e)));
});

test("motionPurpose: 7 nilai kanonik, delight bukan purpose, wajib untuk non-micro", () => {
  const a = video()[0]; a.choreography[0].motionPurpose = "delight";
  assert.ok(errs(a).some((e) => /motionPurpose/.test(e)));
  const b = video()[0]; delete b.choreography[0].motionPurpose;
  assert.ok(errs(b).some((e) => /motionPurpose wajib/.test(e)));
});

test("durasi angka mentah, hex, spring.bouncy pada teks ditolak", () => {
  const a = video()[0]; a.choreography[0].duration = 12;
  assert.ok(errs(a).some((e) => /nama token/.test(e)));
  const b = video()[0]; b.elements[1].content.glyph = "#FFB800";
  assert.ok(errs(b).some((e) => /hex/.test(e)));
  const c = video()[0]; c.choreography[1].spring = "spring.bouncy";
  assert.ok(errs(c).some((e) => /bouncy/.test(e)));
});

test("recipe harus cocok dengan token latar", () => {
  const s = video()[0]; s.background.token = "bg.warm";
  assert.ok(errs(s).some((e) => /dipetakan/.test(e)));
});

test("transisi tanpa action, aset belum approved, teks > 8 kata ditolak", () => {
  const a = video()[0]; delete a.transitionOut.action;
  assert.ok(errs(a).some((e) => /transitionOut\.action/.test(e)));
  const b = video()[0]; b.elements[0].asset = { id: "x", status: "needs-review" };
  assert.ok(errs(b).some((e) => /approved/.test(e)));
  const c = video()[0]; c.elements[1].content.text = "satu dua tiga empat lima enam tujuh delapan sembilan";
  assert.ok(errs(c).some((e) => /kata/.test(e)));
});

test("zona aman 9:16; bleed hanya untuk background", () => {
  const a = video()[0]; a.elements[1].bounds = { x: 0.1, y: 0.02, w: 0.8, h: 0.1 };
  assert.ok(errs(a).some((e) => /zona aman/.test(e)));
  const b = video()[0]; b.elements[1].bleed = true;
  assert.ok(errs(b).some((e) => /bleed/.test(e)));
});

test("waktu relatif dan cue menjadi frame deterministik", () => {
  const s = { choreography: [
    { id: "a", start: 10, duration: "base" }, { id: "b", start: "after:a+3", duration: "fast" },
    { id: "c", start: "with:a+2", duration: "fast" }, { id: "d", start: "cue:b_07-3", duration: "fast" }] };
  const r = resolveStarts(s, T, { b_07: 130 }, 100);
  assert.deepEqual(r.errors, []);
  assert.deepEqual(r.frames, [10, 25, 12, 27]);
  assert.ok(resolveStarts(s, T, {}, 0).errors.some((e) => /cue/.test(e)));
  assert.ok(resolveStarts({ choreography: [{ id: "a", start: "after:b", duration: "base" }, { id: "b", start: "after:a", duration: "base" }] }, T).errors.some((e) => /melingkar/.test(e)));
});

test("format cue seragam b_## / w_###", () => {
  const a = video()[0]; a.audio.beatCue = "beat.b07";
  assert.ok(errs(a).some((e) => /format/.test(e)));
  const b = video()[0]; b.audio.beatCue = "b_07"; b.audio.narrationCue = "w_021";
  assert.deepEqual(errs(b), []);
});

test("brief: pulse_seconds wajib dan <= 3", () => {
  const m = { genres: T.genres, renderRuntime: "remotion" };
  const base = "---\ngenre: education\nviewing: phone\nlanguage: id\naudience: umum\nduration_seconds: 60\npulse_seconds: 3\nformats: [9:16]\nhook_pattern: pertanyaan\ncore_message: x\nclaims: none\nvoice_plan: tts\nmusic_plan: none\nrender_runtime: remotion\n---\n";
  assert.deepEqual(validateBriefFrontmatter(base, m), []);
  assert.ok(validateBriefFrontmatter(base.replace("pulse_seconds: 3", "pulse_seconds: 5"), m).some((e) => /pulse_seconds/.test(e)));
  assert.ok(validateBriefFrontmatter(base.replace("pulse_seconds: 3\n", ""), m).some((e) => /pulse_seconds/.test(e)));
});

test("countWords", () => assert.equal(countWords("AI bukan untuk menggantikan kita, tapi membantu kita."), 8));

test("CLI rhythm: lolos kode 0, jeda panjang kode 2; complete scene_spec menjalankan validator", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "studio-"));
  fs.copyFileSync(path.join(SRC, "pipeline.json"), path.join(root, "pipeline.json"));
  const run = (...a) => spawnSync("node", [path.join(SRC, "scripts", "pipeline.mjs"), ...a], { env: { ...process.env, STUDIO_ROOT: root }, encoding: "utf8" });
  assert.equal(run("init", "demo", "--genre", "education", "--viewing", "phone").status, 0);
  const pd = path.join(root, "projects", "demo");
  fs.mkdirSync(path.join(pd, "scenes"), { recursive: true });
  video().forEach((s) => fs.writeFileSync(path.join(pd, "scenes", `${s.id}.json`), JSON.stringify(s)));
  fs.writeFileSync(path.join(pd, "brief.md"), "---\nduration_seconds: 12\n---\n");
  let r = run("rhythm", "demo");
  assert.equal(r.status, 0, r.stdout + r.stderr);
  assert.match(r.stdout, /maxGapSeconds/);
  const f = path.join(pd, "scenes", "02-b.json"), s = JSON.parse(fs.readFileSync(f, "utf8"));
  s.choreography = s.choreography.filter((c) => c.id === "c1" || c.micro);
  fs.writeFileSync(f, JSON.stringify(s));
  r = run("rhythm", "demo");
  assert.equal(r.status, 2);
  assert.match(r.stdout, /GALAT: DENYUT/);
});
