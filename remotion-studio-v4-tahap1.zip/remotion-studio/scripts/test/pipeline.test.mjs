import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const SRC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const CLI = path.join(SRC, "scripts", "pipeline.mjs");

function sandbox() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "studio-"));
  fs.copyFileSync(path.join(SRC, "pipeline.json"), path.join(root, "pipeline.json"));
  return root;
}
function run(root, ...args) {
  const r = spawnSync("node", [CLI, ...args], { env: { ...process.env, STUDIO_ROOT: root }, encoding: "utf8" });
  return { code: r.status, out: r.stdout + r.stderr };
}
const ok = (root, ...a) => { const r = run(root, ...a); assert.equal(r.code, 0, r.out); return r; };
const write = (root, slug, rel, txt) => { const f = path.join(root, "projects", slug, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, txt); };
const GOOD_BRIEF = `---\ngenre: education\nviewing: phone\nlanguage: id\naudience: siswa SMP\nduration_seconds: 45\npulse_seconds: 3\nformats: [9:16]\nhook_pattern: pertanyaan\ncore_message: Kenapa langit biru\nclaims: none\nvoice_plan: tts\nmusic_plan: none\nrender_runtime: remotion\n---\n# ok\n`;

function upTo(root, slug, ids) {
  const files = { brief: ["brief.md", GOOD_BRIEF], script: ["script.md", "# skrip"] };
  for (const id of ids) {
    ok(root, "start", slug, id);
    if (files[id]) write(root, slug, ...files[id]);
    ok(root, "complete", slug, id);
  }
}

test("init membuat proyek dan mencatat keputusan runtime", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  assert.match(run(root, "decisions", "demo").out, /render_runtime/);
  assert.notEqual(run(root, "init", "demo", "--genre", "education", "--viewing", "phone").code, 0);
});

test("tahap tidak bisa dimulai sebelum prasyarat selesai", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  const r = run(root, "start", "demo", "script");
  assert.equal(r.code, 1);
  assert.match(r.out, /Prasyarat/);
});

test("brief dengan placeholder [ISI] ditolak", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  ok(root, "start", "demo", "brief");
  write(root, "demo", "brief.md", fs.readFileSync(path.join(SRC, "templates", "BRIEF.md"), "utf8"));
  const r = run(root, "complete", "demo", "brief");
  assert.equal(r.code, 1);
  assert.match(r.out, /\[ISI\]|tidak sah|kosong/);
});

test("gerbang: complete dilarang, approve butuh await-human, agen tidak boleh menyetujui", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  upTo(root, "demo", ["brief"]);
  ok(root, "skip", "demo", "research", "--reason", "tidak ada klaim faktual, genre murni");
  upTo(root, "demo", ["script"]);
  ok(root, "start", "demo", "storyboard");
  write(root, "demo", "storyboard.md", "# sb"); write(root, "demo", "shotlist.md", "# sl");
  let r = run(root, "complete", "demo", "storyboard");
  assert.equal(r.code, 2);
  r = run(root, "approve", "demo", "storyboard", "--by", "Budi", "--quote", "setuju");
  assert.equal(r.code, 2);
  ok(root, "await-human", "demo", "storyboard");
  r = run(root, "approve", "demo", "storyboard", "--by", "Claude", "--quote", "setuju");
  assert.equal(r.code, 2);
  assert.match(r.out, /agen/);
  r = run(root, "approve", "demo", "storyboard", "--by", "Budi", "--quote", "ok lanjut");
  assert.equal(r.code, 0, r.out);
  assert.match(run(root, "status", "demo").out, /storyboard\s+completed.*oleh Budi/);
});

test("keluaran berubah setelah diajukan => persetujuan ditolak", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  upTo(root, "demo", ["brief"]);
  ok(root, "skip", "demo", "research", "--reason", "tidak ada klaim faktual, genre murni");
  upTo(root, "demo", ["script"]);
  ok(root, "start", "demo", "storyboard");
  write(root, "demo", "storyboard.md", "# sb"); write(root, "demo", "shotlist.md", "# sl");
  ok(root, "await-human", "demo", "storyboard");
  write(root, "demo", "storyboard.md", "# sb diubah diam-diam");
  const r = run(root, "approve", "demo", "storyboard", "--by", "Budi", "--quote", "ok lanjut");
  assert.equal(r.code, 2);
  assert.match(r.out, /berubah/);
});

test("drift: keluaran tahap selesai diubah memblokir tahap berikutnya", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  upTo(root, "demo", ["brief"]);
  ok(root, "skip", "demo", "research", "--reason", "tidak ada klaim faktual, genre murni");
  write(root, "demo", "brief.md", GOOD_BRIEF + "\ntambahan\n");
  const r = run(root, "start", "demo", "script");
  assert.equal(r.code, 1);
  assert.match(r.out, /berubah sejak ditutup/);
});

test("tahap bergerbang tidak boleh dilewati; riset boleh dengan alasan", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  assert.notEqual(run(root, "skip", "demo", "storyboard", "--reason", "malas banget deh").code, 0);
  upTo(root, "demo", ["brief"]);
  assert.notEqual(run(root, "skip", "demo", "research", "--reason", "pendek").code, 0);
  ok(root, "skip", "demo", "research", "--reason", "tidak ada klaim faktual, genre murni");
});

test("batas putaran per adegan: putaran ke-4 keluar kode 3", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  for (let i = 0; i < 3; i++) ok(root, "round", "demo", "s1");
  assert.equal(run(root, "round", "demo", "s1").code, 3);
  ok(root, "round", "demo", "s2");
});

test("keputusan terkunci tidak bisa diganti tanpa approved-by", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  const base = ["decide", "demo", "--category", "render_runtime", "--subject", "runtime", "--choice", "ffmpeg", "--reason", "coba", "--by", "agent"];
  const r = run(root, ...base);
  assert.equal(r.code, 1);
  assert.match(r.out, /TERKUNCI/);
  ok(root, ...base, "--approved-by", "Budi");
});

test("blocker harus lengkap", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  assert.notEqual(run(root, "block", "demo", "brief", "--kind", "api_error").code, 0);
  ok(root, "block", "demo", "brief", "--kind", "api_error", "--attempted", "panggil TTS", "--failed", "401", "--option", "ganti kunci", "--recommendation", "ganti kunci");
});

test("invalidate mengembalikan tahap ke belum dimulai dan mengarsipkan", () => {
  const root = sandbox();
  ok(root, "init", "demo", "--genre", "education", "--viewing", "phone");
  upTo(root, "demo", ["brief"]);
  ok(root, "invalidate", "demo", "brief", "--reason", "brief perlu diubah total");
  assert.match(run(root, "status", "demo").out, /brief\s+pending/);
  assert.ok(fs.readdirSync(path.join(root, "projects", "demo", "checkpoints", "_archive")).length >= 1);
});
