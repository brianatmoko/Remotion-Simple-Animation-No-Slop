#!/usr/bin/env node
// CLI pipeline. Satu-satunya jalan mengubah status tahap. Kode keluar: 0 ok, 1 galat, 2 pelanggaran gerbang, 3 batas putaran.
import { repoRoot } from "./lib/fsx.mjs";
import { loadManifest } from "./lib/manifest.mjs";
import * as cp from "./lib/checkpoint.mjs";
import fs from "node:fs";
import path from "node:path";
import { loadProjectScenes, loadCues, validateRhythm } from "./lib/scene-spec.mjs";
import { parseFrontmatter } from "./lib/validators.mjs";
import { appendDecision, readDecisions, DecisionError } from "./lib/decisions.mjs";

function parseArgs(argv) {
  const pos = [];
  const flags = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const k = a.slice(2);
      const v = argv[i + 1] !== undefined && !argv[i + 1].startsWith("--") ? argv[++i] : true;
      if (k === "option") (flags.option ??= []).push(v); else flags[k] = v;
    } else pos.push(a);
  }
  return { pos, flags };
}

const USAGE = `Pemakaian: node scripts/pipeline.mjs <perintah> <slug> [tahap] [opsi]
  stages                                  daftar tahap dari manifest
  init <slug> --genre G --viewing V       buat proyek
  status <slug>                           status semua tahap
  start <slug> <tahap>
  complete <slug> <tahap> [--summary S]
  await-human <slug> <tahap> [--summary S]
  approve <slug> <tahap> --by NAMA --quote "kata manusia"
  reject <slug> <tahap> --note "yang diubah"
  block <slug> <tahap> --kind K --attempted A --failed F --option O [--option O2] --recommendation R
  skip <slug> <tahap> --reason "..."
  invalidate <slug> <tahap> --reason "..."
  round <slug> <sceneId>                  catat putaran perbaikan adegan
  decide <slug> --category C --subject S --choice X --reason R --by B [--approved-by H]
  decisions <slug>
  rhythm <slug>                           peta denyut dari scenes/*.json (galat = kode 2)`;

function main() {
  const { pos, flags } = parseArgs(process.argv.slice(2));
  const [cmd, slug, stage] = pos;
  const root = repoRoot();
  const ctx = { root, slug };
  const out = (o) => console.log(typeof o === "string" ? o : JSON.stringify(o, null, 2));
  switch (cmd) {
    case "stages": { const m = loadManifest(root); for (const s of m.stages) out(`${s.no.padEnd(3)} ${s.id.padEnd(12)} ${s.owner}${s.gate ? `  [GERBANG: ${s.gate.id}]` : ""}${s.skippable ? "  (boleh dilewati)" : ""}`); return; }
    case "init": cp.initProject(ctx, { genre: flags.genre, viewing: flags.viewing }); out(`Proyek '${slug}' dibuat.`); return;
    case "status": for (const s of cp.statusAll(ctx)) out(`${s.no.padEnd(3)} ${s.id.padEnd(12)} ${s.status}${s.gate ? ` [gerbang:${s.gate}]` : ""}${s.revision ? ` rev${s.revision}` : ""}${s.drift.length ? ` DRIFT:${s.drift.join(",")}` : ""}${s.approval ? ` oleh ${s.approval.by}` : ""}`); return;
    case "start": cp.start(ctx, stage); out(`'${stage}' dimulai.`); return;
    case "complete": cp.complete(ctx, stage, { summary: flags.summary }); out(`'${stage}' selesai.`); return;
    case "await-human": cp.awaitHuman(ctx, stage, { summary: flags.summary }); out(`'${stage}' menunggu persetujuan manusia. BERHENTI di sini sampai manusia menjawab.`); return;
    case "approve": cp.approve(ctx, stage, { by: flags.by, quote: flags.quote }); out(`'${stage}' disetujui.`); return;
    case "reject": cp.reject(ctx, stage, { note: flags.note }); out(`'${stage}' ditolak; kembali in_progress.`); return;
    case "block": cp.block(ctx, stage, { kind: flags.kind, attempted: flags.attempted, failed: flags.failed, options: [].concat(flags.option ?? []), recommendation: flags.recommendation }); out(`'${stage}' ditandai terblokir.`); return;
    case "skip": cp.skip(ctx, stage, { reason: flags.reason }); out(`'${stage}' dilewati.`); return;
    case "invalidate": out({ reset: cp.invalidate(ctx, stage, { reason: flags.reason, by: flags.by }) }); return;
    case "round": out(cp.recordRound(ctx, stage)); return;
    case "decide": cp.ensureProject(ctx); out(appendDecision(cp.projectDirOf(ctx), { category: flags.category, subject: flags.subject, choice: flags.choice, reason: flags.reason, by: flags.by, approvedBy: flags["approved-by"] })); return;
    case "decisions": cp.ensureProject(ctx); out(readDecisions(cp.projectDirOf(ctx))); return;
    case "rhythm": {
      cp.ensureProject(ctx);
      const dir = cp.projectDirOf(ctx), { scenes, errs } = loadProjectScenes(dir);
      if (errs.length) { errs.forEach((e) => console.error(e)); process.exit(1); }
      const bf = path.join(dir, "brief.md");
      const brief = fs.existsSync(bf) ? parseFrontmatter(fs.readFileSync(bf, "utf8")) ?? {} : {};
      const r = validateRhythm(scenes, { brief, cues: loadCues(dir) });
      out("DENYUT (waktu | adegan | tipe | target)");
      for (const c of r.clusters) out(`${r.fmt(c.frame).padStart(6)} | ${String(c.scene).padEnd(22)} | ${c.type.padEnd(10)} | ${c.target}${c.wow ? "  *WOW" : ""}`);
      out(r.stats);
      r.warnings.forEach((w) => out(`PERINGATAN: ${w}`));
      r.errors.forEach((e) => out(`GALAT: ${e}`));
      if (r.errors.length) process.exit(2);
      return;
    }
    default: console.log(USAGE); process.exit(cmd ? 1 : 0);
  }
}

try { main(); } catch (e) {
  console.error(e.message);
  process.exit(e.exitCode ?? (e instanceof cp.GateViolation ? 2 : 1));
}
