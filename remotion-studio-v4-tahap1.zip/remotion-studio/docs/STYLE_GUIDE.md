# STYLE_GUIDE.md

> Gaya visual **bold vector, cerah, kuning merek**: bentuk tegas, kontur navy tebal, warna datar, bayangan blok. Semua nilai di sini adalah **token**. Kode dan spec hanya boleh merujuk nama token.
> Status: **v2**. Palet ditetapkan pemilik (`DECISIONS.md` D-015). Angka lain adalah **titik awal** yang dikalibrasi di M1 (style frame) dan M6 (Lapis 1). Setelah itu, perubahan wajib lewat `DECISIONS.md`.
> Docx rencana lama tidak berlaku untuk angka apa pun (D-014).

## 1. Definisi gaya

Bold vector cerah berarti:

1. **Bentuk geometris sederhana**, sudut membulat; siluet terbaca dari jauh.
2. **Kontur navy tebal seragam** pada semua bentuk utama.
3. **Warna datar** dari palet merek; tanpa gradien, tanpa tekstur foto.
4. **Bayangan blok navy**: padat, bergeser, tanpa blur.
5. **Latar selalu cerah** (keluarga kuning). Terang dan ceria adalah identitas.
6. **Satu fokus per frame**; sisanya lebih kecil atau lebih tenang.
7. **Simpel dan seru**: sedikit elemen, sedikit kata, gerak yang punya karakter (`docs/SIMPLE_AND_FUN.md`).

Bukan gaya ini: gradien halus, bayangan lembut, foto realistis, kontur tipis, ornamen berlebihan, latar gelap.

## 2. Kanvas dan grid

| Rasio | Ukuran | Dipakai |
|---|---|---|
| 16:9 | 1920 x 1080 | dasar |
| 9:16 | 1080 x 1920 | Shorts/Reels/TikTok |
| 1:1 | 1080 x 1080 | feed |

- Unit spacing dasar **8 px**; semua jarak kelipatan 8.
- Grid: 12 kolom (16:9), 6 kolom (9:16), 8 kolom (1:1). Titik fokus di sekitar persilangan sepertiga.

## 3. Zona aman

| Rasio | Margin aman (teks/logo/CTA) | Catatan |
|---|---|---|
| 16:9 | 96 px kiri-kanan, 54 px atas-bawah (5%) | |
| 9:16 | atas ≈250 px, bawah ≈420 px bebas teks penting; kiri-kanan 64 px | Perkiraan; **verifikasi per platform** di `QA_CHECKLIST.md`. Tinggi layak = 1920 - 250 - 420 = **1250 px** |
| 1:1 | 5% tiap sisi | |

## 4. Palet (token warna)

Tiga keluarga warna, sesuai merek: **kuning (primer)**, **putih (ikon dan SVG)**, **navy (aksen)**. Hex hanya boleh ada di `packages/tokens/color.ts`.

| Token | Hex | Peran |
|---|---|---|
| `sun500` | `#FFB800` | **PRIMER merek**, kuning agak oranye. Latar dominan, bentuk utama |
| `sun300` | `#FFD95A` | latar hangat, motif latar, sorotan lembut |
| `sun100` | `#FFF3C4` | latar paling terang (adegan tenang, penjelasan) |
| `sun700` | `#F59300` | latar energi: momen puncak, CTA. Tetap kuning, bukan oranye penuh |
| `white` | `#FFFFFF` | **ikon, SVG, kartu**. Permukaan di atas latar |
| `navy900` | `#0F1E4A` | kontur, teks utama, bayangan blok, chip aksen |
| `navy700` | `#2A3F7A` | teks sekunder, detail aksen |

### Token semantik (yang dipakai adegan)

| Token | Nilai | Catatan |
|---|---|---|
| `bg.primary` | `sun500` | latar default |
| `bg.soft` | `sun100` | adegan tenang |
| `bg.warm` | `sun300` | variasi |
| `bg.energy` | `sun700` | momen puncak/CTA |
| `surface.card` | `white` | kartu, panel |
| `surface.chip` | `navy900` | chip aksen (teks `white` atau `sun500`) |
| `icon.fill` / `icon.stroke` | `white` / `navy900` | ikon dan SVG |
| `text.main` / `text.soft` | `navy900` / `navy700` | |
| `text.onNavy` | `white` atau `sun500` | hanya di atas `surface.chip` |

### Aturan latar (tegas)

- Latar penuh **hanya** dari `bg.*` (empat langkah kuning). **Navy tidak pernah jadi latar penuh**, dan putih tidak jadi latar penuh (putih = permukaan/kartu/ikon).
- Satu langkah latar per adegan. Latar antar adegan berurutan **berganti langkah** (mis. `primary` → `soft` → `primary` → `energy`) agar ritme terasa. Pergantian langkah kuning tetap perubahan terang-gelap (mis. `sun500` ke `sun100` selisih luminans relatif ≈0,34), jadi tetap dihitung dalam batas kilatan ≤ 3 per detik (`MOTION_SYSTEM.md` bagian 10).
- Latar punya **motif datar berkontras rendah** dari langkah kuning yang lain (bagian 5), bukan gradien.

### Anggaran area warna per frame (titik awal, dikalibrasi di M6)

| Keluarga | Porsi area |
|---|---|
| Kuning (`sun*`) | ≥ 55% |
| Putih | 15% sampai 35% |
| Navy (kontur, teks, bayangan, chip) | ≤ 15% |

Navy adalah **aksen**, bukan warna dominan. Kuning selalu menang.

### Kontras (dihitung, WCAG 2.x, 7 Okt 2026)

| Teks / objek | Latar | Rasio | Penggunaan |
|---|---|---|---|
| `navy900` | `white` | 16,1:1 | semua ukuran |
| `navy900` | `sun100` | 14,5:1 | semua ukuran |
| `navy900` | `sun300` | 11,7:1 | semua ukuran |
| `navy900` | `sun500` | 9,3:1 | semua ukuran |
| `navy900` | `sun700` | 6,9:1 | semua ukuran |
| `navy700` | `sun100` / `white` | 9,0 / 10,0:1 | teks sekunder |
| `navy700` | `sun500` | 5,8:1 | teks sekunder |
| `white` | `navy900` | 16,1:1 | teks di chip navy |
| `sun500` | `navy900` | 9,3:1 | teks aksen di chip navy |
| `white` | `sun500` / `sun300` / `sun700` | **1,7 / 1,4 / 2,3:1** | **dilarang untuk teks** |
| `white` | `sun100` | 1,1:1 | **dilarang** tanpa kontur |

**Konsekuensi untuk ikon putih:** putih nyaris hilang di atas kuning. Maka **ikon dan SVG putih wajib berkontur `navy900`** (`stroke.main`/`stroke.detail`), atau diletakkan di atas `surface.chip`/kartu putih berkontur. Kontur navy-lah yang membuat bentuk terbaca (target 3:1 untuk objek grafis).

Validator kontras otomatis (Lapis 1) adalah sumber kebenaran: 4,5:1 teks biasa, 3:1 teks besar dan objek grafis.

### Resep warna (variasi tanpa menambah warna)

| Resep | Latar | Hero | Pendukung | Cocok untuk |
|---|---|---|---|---|
| Terang klasik | `bg.primary` | kartu putih + kontur + bayangan navy | ikon putih berkontur | hook, penjelasan |
| Krim tenang | `bg.soft` | bentuk `sun500` berkontur | ikon putih, teks navy | langkah demi langkah |
| Hangat penekanan | `bg.warm` | chip navy + teks putih/kuning | bentuk putih | penekanan, angka besar |
| Energi | `bg.energy` | kartu putih besar | bentuk `sun300` | momen puncak, CTA |
| Panel terbagi | `bg.primary` + panel putih ≤ 50% | isi di panel putih | ikon di sisi kuning | perbandingan |

Pilih resep per adegan di storyboard. Tidak ada dua adegan berurutan dengan resep yang sama.

## 5. Motif latar (membuat latar hidup tanpa menambah warna)

Token `motif.*`, semuanya datar dan memakai **langkah kuning lain** dari latarnya:

| Motif | Bentuk |
|---|---|
| `motif.rays` | sinar matahari melingkar (sorotan di sekitar hero) |
| `motif.dots` | kisi titik |
| `motif.waves` | pita bergelombang |
| `motif.stripes` | garis diagonal lebar |
| `motif.blobs` | blob melayang besar |

Aturan: rasio kontras motif terhadap latarnya **antara 1,1:1 dan 1,6:1** (contoh terukur: `sun300` di `sun500` = 1,27:1; `sun700` di `sun500` = 1,34:1). Motif boleh bergerak pelan (`breathe`, `parallax`), tidak pernah bersaing dengan hero. Satu motif per adegan.

## 6. Bentuk, kontur, bayangan

| Token | Nilai | Keterangan |
|---|---|---|
| `stroke.main` | 8 px | kontur `navy900` elemen utama |
| `stroke.detail` | 4 px | detail kecil |
| `radius.sm / md / lg` | 12 / 24 / 48 px | `full` untuk pil/lingkaran |
| `shadow.block` | offset (12, 12), `navy900`, tanpa blur | standar |
| `shadow.block-sm` | offset (6, 6) | elemen kecil |

- Ujung dan sambungan garis `round`.
- Arah bayangan blok **sama di seluruh video** (default kanan-bawah).
- Semua bentuk berwarna dan ikon putih berkontur `navy900`, kecuali motif latar.
- Bentuk dasar: lingkaran, persegi membulat, segitiga membulat, kapsul, blob (blob dari generator proses).

## 7. Tipografi

Dua keluarga font OFL, dimuat dari `packages/tokens/fonts.ts` (`REMOTION_RULES.md` R5).

| Token | Keluarga | Bobot | Dipakai |
|---|---|---|---|
| `font.display` | Poppins | 800 | judul, kinetic type, CTA |
| `font.body` | Inter | 500 dan 700 | isi, caption, label |

### Skala ukuran menurut konteks tonton

Konteks tonton (`viewing: phone | large`) ditulis di `brief.md`; token `type.*` memilih skala. Hitungannya: ponsel 390 px menampilkan video 16:9 (1920 px) dengan skala ≈0,2, dan video 9:16 (1080 px) dengan skala ≈0,36.

| Token | 9:16 dan layar besar | **16:9 ditonton di ponsel** | Dipakai |
|---|---|---|---|
| `type.hero` | 160 | 200 | satu kata/angka besar |
| `type.title` | 96 | 120 | judul adegan |
| `type.subtitle` | 56 | 88 | subjudul |
| `type.body` | 40 | 64 | isi |
| `type.caption` | 44 | 64 | caption (`CAPTIONS.md`) |
| `type.label` | 32 | 60 | label diagram (minimum mutlak) |

- Minimum 32 px berlaku **hanya** untuk 9:16 atau layar besar (label 32 px di 9:16 menjadi ≈11,6 px di ponsel, batas bawah). Untuk 16:9 di ponsel, minimum ≈59 px pada 1080p (≈12 px di layar).
- **Batas kata (lebih ketat dari v1, D-030):** judul ≤ **6 kata**, ≤ 2 baris; isi ≤ **8 kata** per layar (edukasi) dan lebih ringkas untuk iklan/hiburan.
- Perataan: kiri untuk isi; tengah untuk judul pendek, angka, CTA. Tinggi baris 1,1 (display), 1,3 (body).
- Teks statis di dalam SVG aset diubah menjadi path (`SVG_STANDARDS.md`); teks yang bergerak tetap teks React.
- Teks selalu `navy900`/`navy700` di atas kuning dan putih; `white`/`sun500` hanya di atas `surface.chip`.
- Uji otomatis: render still lebar 390 px, jalankan OCR, setiap string di spec harus ditemukan (cocok ≥ 95%).

## 8. Komposisi: definisi elemen

Dua hitungan berbeda, bukan konflik angka (D-014):

| Istilah | Dihitung | Batas (titik awal) |
|---|---|---|
| **Elemen utama** | hero + pendukung yang membawa pesan | **3 sampai 5** per layar |
| **Elemen terlihat** | semua elemen di frame, termasuk dekorasi dan motif | edukasi ≤ 12, iklan ≤ 10, hiburan ≤ 16 |

Aturan lain:
- **Satu hero per frame**: lebih besar, lebih kontras (kartu putih/chip navy di atas kuning), atau bergerak.
- **Ruang napas**: ≥ 20% area kosong (edukasi dan iklan).
- **Hierarki tiga tingkat**: hero, pendukung, latar.
- **Arah pandang**: elemen/karakter menghadap ruang kosong atau konten.
- Latar bergerak berkontras rendah (bagian 5).

### Turunan 9:16 dari 16:9 (prioritas elemen)

Tiap elemen di spec punya `priority`: `must` | `should` | `optional`. Penetapnya Motion Designer di tahap Spec; storyboard yang Anda setujui menandai mana `must`.

1. Susun menumpuk; ukuran teks tidak boleh turun di bawah minimum konteks.
2. Jika tinggi total > **1250 px**, buang `optional` dari prioritas terendah.
3. Jika masih tidak muat, `must` **tidak pernah dibuang otomatis**: Lapis 1 melaporkan kegagalan dan adegan butuh override manual.
4. Contoh: tiga ikon bertumpuk setinggi 400 px muat (1200); 440 px tidak (1320), sehingga harus diskalakan atau salah satu dibuang.

Ukur: persentase adegan 9:16 lolos Lapis 1 tanpa override manual; target > 80% setelah templat stabil.

## 9. Karakter

- **Pilot edukasi tidak memakai rig karakter** (D-028). Rasa karakter datang dari *shape acting*: bentuk dasar yang hidup lewat gerak (komponen primitif `Blobby`: blob dengan dua mata titik, kedip, squash dan stretch; usulan, diuji di M1).
- Rig berlapis dengan sendi bernama baru dipakai setelah **uji karakter AI** lulus (D-024, sebelum M4).
- Siluet harus terbaca dalam satu warna. Set ekspresi sebagai variasi lapisan.
- Karakter: kulit/rambut/pakaian tetap dari token; kuning merek dipakai untuk elemen khas, kontur navy.
- Tidak menyerupai orang nyata, tokoh publik, atau karakter berhak cipta.

## 10. Ikon, grafik, diagram

- Ikon: satu keluarga gaya, **isi putih + kontur navy**, kelipatan 8 px.
- Grafik data: satu pesan per grafik; label langsung pada elemen. Data sorotan = `navy900`; data lain = putih berkontur atau `sun300`. Tidak ada legenda terpisah bila bisa dihindari.
- Diagram edukasi dibangun bertahap: tiap langkah menambah satu elemen dan menyorot yang baru.

## 11. Hal yang dilarang

- Warna di luar token; gradien; blur sebagai gaya.
- Latar navy atau putih penuh; latar gelap.
- Teks putih di atas kuning; ikon putih tanpa kontur navy.
- Teks di bawah minimum konteks; teks di luar zona aman.
- Lebih dari satu motif atau satu latar per adegan.
- Campuran gaya (ikon kontur tipis di sebelah ilustrasi bold) dalam satu video.
- Logo, merek dagang, wajah orang dikenali tanpa izin. Aset yang belum `approved`.

## 12. Style frame (gerbang persetujuan M1)

Art Director membuat satu still per genre (mulai **edukasi**): latar cerah + motif, hero kartu putih, judul, ikon putih berkontur, bayangan blok, caption. Seed visual dipilih dari **contact sheet 12 seed** (satu gambar); yang dipilih dan ditolak dicatat di `projects/<slug>/seeds.md` beserta alasan (D-027). Anda boleh veto. Yang disetujui disimpan di `golden/style/`.

Ukur: jumlah seed yang ditolak per proyek (selalu 0 = penerimaan pertama, bukan keputusan artistik).

## 13. Bentuk berkas token (acuan)

```ts
// packages/tokens/color.ts  (hex hanya di sini)
export const COLOR = {
  sun100: "#FFF3C4", sun300: "#FFD95A", sun500: "#FFB800", sun700: "#F59300",
  white: "#FFFFFF", navy900: "#0F1E4A", navy700: "#2A3F7A",
} as const;

export const THEME = {
  bg: { primary: COLOR.sun500, soft: COLOR.sun100, warm: COLOR.sun300, energy: COLOR.sun700 },
  surface: { card: COLOR.white, chip: COLOR.navy900 },
  icon: { fill: COLOR.white, stroke: COLOR.navy900 },
  text: { main: COLOR.navy900, soft: COLOR.navy700, onNavy: COLOR.white, accentOnNavy: COLOR.sun500 },
} as const;

// packages/tokens/shape.ts
export const STROKE = { main: 8, detail: 4 } as const;
export const RADIUS = { sm: 12, md: 24, lg: 48, full: 9999 } as const;
export const SHADOW = { block: { x: 12, y: 12 }, blockSm: { x: 6, y: 6 } } as const;

// packages/tokens/type.ts  (skala dipilih oleh brief.viewing)
export const TYPE = {
  large: { hero: 160, title: 96, subtitle: 56, body: 40, caption: 44, label: 32 },
  phone16x9: { hero: 200, title: 120, subtitle: 88, body: 64, caption: 64, label: 60 },
} as const;
```
