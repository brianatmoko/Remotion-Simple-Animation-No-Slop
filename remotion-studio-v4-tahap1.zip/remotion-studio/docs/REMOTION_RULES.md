# REMOTION_RULES.md

> Aturan keras penulisan kode Remotion. Pelanggaran ditangkap lint/CI bila memungkinkan.
> Catatan: nama API di bawah adalah yang umum dipakai Remotion. **Verifikasi terhadap versi terkunci di M0.8** dan baca dokumentasi versi tersebut sebelum memakai API yang tidak tercantum di sini.

## Model mental

Remotion merender video dengan membuka komposisi React **satu frame per satu frame**, mengambil gambar tiap frame, lalu menyatukannya. Karena itu:

> Tampilan sebuah frame harus merupakan **fungsi murni** dari nomor frame dan props. Tidak ada yang boleh bergantung pada waktu nyata, keadaan yang berubah sendiri, atau urutan render.

## R1. Tanpa animasi CSS

Dilarang: `transition`, `animation`, `@keyframes`, kelas `animate-*` dan `transition-*` Tailwind, library animasi berbasis DOM/timer (mis. yang memakai `requestAnimationFrame` sendiri).
Alasan: render per frame tidak melihat animasi CSS secara benar; hasil render salah atau berkedip.

```tsx
// ❌ SALAH
<div className="transition-all duration-500 opacity-0 animate-fade-in" />

// ✅ BENAR
const frame = useCurrentFrame();
const opacity = interpolate(frame, [0, 15], [0, 1], { extrapolateRight: "clamp" });
<div style={{ opacity }} />
```

## R2. Semua gerak dihitung dari frame

Gunakan `useCurrentFrame()` dan `useVideoConfig()`. Pakai `interpolate`, `spring`, `interpolateColors`. Dilarang `setState` + `setTimeout`/`setInterval`, dan dilarang `useEffect` untuk menggerakkan sesuatu.

```tsx
// ✅ spring selalu dengan fps dari konfigurasi
const { fps } = useVideoConfig();
const scale = spring({ frame, fps, config: SPRING.snappy });
```

## R3. Selalu jepit (clamp) interpolasi

`interpolate` secara default mengekstrapolasi di luar rentang. Tentukan sikapnya secara eksplisit.

```tsx
// ❌ nilai melewati batas setelah frame 15
interpolate(frame, [0, 15], [0, 1]);

// ✅
interpolate(frame, [0, 15], [0, 1], {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
  easing: EASE.out,        // dari token
});
```

Rentang input harus naik tegas (strictly increasing). Rentang dengan titik sama menimbulkan galat.

## R4. Waktu: Sequence, Series, Transition

- Setiap elemen yang muncul pada waktu tertentu dibungkus `<Sequence from={..} durationInFrames={..}>`. **Di dalam Sequence, `useCurrentFrame()` mengembalikan frame lokal (dimulai dari 0).** Tulis animasi relatif terhadap awal Sequence.
- Adegan berurutan memakai `<Series>`; tumpang tindih (overlap) antar adegan dengan transisi memakai paket transisi resmi (`TransitionSeries`) dan komponen transisi dari `TRANSITIONS.md`.
- Gunakan `premountFor` pada Sequence agar elemen berat (font, gambar, SVG besar) sudah dipasang sebelum tampil.
- Jangan menghitung `from` dengan angka mentah. Ambil dari spec/token/penanda audio.

```tsx
<Series>
  {scenes.map((s) => (
    <Series.Sequence key={s.id} durationInFrames={s.durationFrames} premountFor={fps}>
      <Scene spec={s} />
    </Series.Sequence>
  ))}
</Series>
```

## R5. Font dimuat sebelum render

Font harus siap sebelum frame pertama diambil, kalau tidak teks akan berganti font di tengah video.

- Gunakan loader resmi untuk font (paket Google Fonts Remotion, atau `@font-face` dengan berkas lokal di `public/`).
- Muat **hanya bobot dan subset yang dipakai** (lihat `STYLE_GUIDE.md`).
- Tunggu pemuatan dengan mekanisme yang disediakan Remotion; tidak boleh render dengan font fallback.
- Font hanya dimuat di satu tempat: `packages/tokens/fonts.ts`.

## R6. Memuat data/aset asinkron

Bila harus memuat sesuatu secara asinkron di dalam komposisi, tahan render dengan `delayRender()` dan lepaskan dengan `continueRender()` **di semua jalur** (sukses dan galat). Beri label dan batas waktu. Lebih disukai: jangan ambil data jaringan saat render; ubah menjadi berkas lokal atau props lewat `calculateMetadata`.

```tsx
// ✅ pola aman
const [handle] = useState(() => delayRender("load-rig-svg"));
useEffect(() => {
  load().then(setData).catch(cancelRender).finally(() => continueRender(handle));
}, [handle]);
```
(`useEffect` di sini hanya untuk memuat data, bukan untuk animasi.)

## R7. Determinisme

Render yang sama harus menghasilkan video yang sama.

| Dilarang | Gunakan |
|---|---|
| `Math.random()` | `random("seed-string")` dari Remotion |
| `Date.now()`, `new Date()` untuk tampilan | nomor frame |
| `fetch` ke jaringan saat render | data lokal / `calculateMetadata` |
| urutan iterasi objek yang tak stabil | array berurutan |
| noise tanpa seed | noise berbasis frame + seed tetap |

## R8. Aset

- Berkas statis lewat `staticFile()`; gambar lewat komponen `<Img>` (bukan `<img>`), agar render menunggu gambar siap.
- Aset berasal dari `assets.json` berstatus `approved`. Jangan menaruh aset luar langsung di `public/`.
- SVG inline sebagai komponen React bila bagian-bagiannya dianimasikan; SVG sebagai `<Img>` hanya untuk gambar statis. Standar SVG ada di `SVG_STANDARDS.md`.

## R9. Menganimasikan SVG

- Animasikan atribut `transform`, `opacity`, `stroke-dashoffset`, dan properti geometri dari nilai frame. Jangan SMIL (`<animate>`) dan jangan animasi CSS di dalam SVG.
- Garis yang "digambar bertahap": gunakan utilitas path Remotion (paket `@remotion/paths`) atau `stroke-dasharray`/`dashoffset` yang dihitung dari panjang path.
- Titik pivot rotasi/skala ditetapkan eksplisit (`transformOrigin` atau `transform-box`); sendi karakter punya titik pivot terdokumentasi di katalog.
- Hindari filter berat (blur besar, drop-shadow Gaussian) pada elemen besar. Gaya kita memakai **bayangan blok**, bukan blur.

## R10. Komposisi, props, dan durasi

- Setiap komposisi terdaftar di `Root` dengan `id`, `width`, `height`, `fps`, dan **schema Zod** untuk props (bila terverifikasi di M0.8).
- Durasi komposisi dihitung di `calculateMetadata` dari spec dan audio, bukan ditulis tangan.
- Satu spec → tiga komposisi (16:9, 9:16, 1:1) yang berbagi komponen adegan; perbedaan hanya di aturan tata letak.

## R11. Audio

- Audio lewat komponen audio Remotion dengan `volume` sebagai fungsi frame (untuk ducking dan fade).
- Perubahan adegan dan hero beat dijatuhkan pada penanda ketukan dari `timing` (toleransi ±1 frame).
- Analisis audio (gelombang, spektrum) dilakukan sekali dan di-cache sebagai JSON; jangan menganalisis ulang tiap frame.

## R12. Performa

- Komponen berat dipasang `React.memo`; hasil hitungan mahal di-`useMemo` dengan kunci yang stabil.
- Batasi jumlah elemen SVG per frame (anggaran di `QA_CHECKLIST.md`).
- Hindari pembuatan objek/fungsi besar di dalam render tiap frame bila bisa dihitung sekali di luar.
- Atur konkurensi render sesuai CPU; jangan menaikkan tanpa mengukur.

## R13. Versi dan API

- Semua `remotion` dan `@remotion/*` di versi **persis sama**, tanpa `^`/`~` (`DECISIONS.md` D-008).
- Sebelum memakai API yang tidak ada di dokumen ini: baca dokumentasi versi terkunci. Bila tidak yakin API ada, **jangan menebak**; tulis pertanyaan di `TASKS.md`.
- Catat API baru yang terverifikasi di bagian "API terverifikasi" di bawah.

## R14. Struktur kode adegan

```tsx
// Bentuk standar komponen adegan (templat)
export const Scene: React.FC<{ spec: SceneSpec }> = ({ spec }) => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{ backgroundColor: THEME.bg[spec.background] }}>
      <Camera spec={spec.camera}>
        {spec.elements.map((el) => (
          <Element key={el.id} el={el} choreography={spec.choreography} />
        ))}
      </Camera>
      <SafeZoneDebug enabled={DEBUG} />
    </AbsoluteFill>
  );
};
```

- Adegan tidak mengandung angka ajaib. Semua dari spec dan token.
- Satu berkas = satu komponen; ekspor dari `index.ts` per paket.
- Skala teks dipilih dari `TYPE[brief.viewing]`, bukan angka tetap (`STYLE_GUIDE.md` bagian 7).

## Daftar periksa cepat sebelum commit

- [ ] Tidak ada `transition`/`animation`/`animate-*`
- [ ] Tidak ada `Math.random`, `Date.now`, `fetch` saat render
- [ ] Semua `interpolate` punya clamp
- [ ] Semua `spring` memakai `fps` dari `useVideoConfig`
- [ ] Elemen waktunya dibungkus `Sequence`/`Series`, memakai `premountFor` bila berat
- [ ] Font hanya dari loader tunggal; tunggu sampai siap
- [ ] `delayRender` selalu punya `continueRender` di semua jalur
- [ ] Warna/ukuran/durasi/easing dari token
- [ ] `npm run check` lolos

## API terverifikasi (diisi di M0.8 dan seterusnya)

| API / paket | Dipakai untuk | Versi terverifikasi | Catatan |
|---|---|---|---|
| | | | |
