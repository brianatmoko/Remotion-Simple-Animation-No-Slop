# SVG_STANDARDS.md

> Standar semua berkas SVG yang masuk pustaka, baik buatan sendiri maupun dari luar. Dipakai oleh Asset Curator, skill "bersihkan SVG", dan QA Lapis 1.
> Nilai angka bersifat draft; final bersama `STYLE_GUIDE.md` di M1.

## 1. Prinsip

1. **Seragam**: semua SVG mengikuti aturan yang sama agar bisa dipertukarkan dan dianimasikan.
2. **Bisa dianimasikan**: bagian yang bergerak punya `id` dan titik pivot jelas.
3. **Aman**: SVG dari luar dianggap **tidak tepercaya** sampai dibersihkan.
4. **Ringan**: ukuran dan jumlah elemen dibatasi demi performa render.

## 2. Struktur berkas

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="none">
  <g id="layer-body">…</g>
  <g id="layer-arm-left" data-pivot="120 260">…</g>
  …
</svg>
```

- `viewBox` wajib; tidak boleh ada atribut `width`/`height` tetap (ukuran diatur komponen).
- Satu `<svg>` akar; tanpa `<style>`, tanpa atribut `class` dari luar, tanpa `style` inline kecuali yang dihasilkan pipeline.
- Tanpa metadata editor (Inkscape, Illustrator, Sketch), komentar, `<title>`/`<desc>` yang bukan untuk aksesibilitas.

## 3. viewBox seragam

| Jenis | viewBox |
|---|---|
| Ikon | `0 0 24 24` (dibesarkan komponen ke kelipatan 8) atau `0 0 64 64` untuk ikon bold |
| Objek/elemen ilustrasi | `0 0 512 512` |
| Karakter (rig penuh) | `0 0 1024 1024` |
| Latar/pemandangan | rasio kanvas (`0 0 1920 1080`, dst.) |

Pipeline menormalkan viewBox: pusatkan konten, beri padding konsisten, pertahankan rasio.

## 4. Penamaan id layer

Format: `kategori-bagian[-sisi][-variasi]`, huruf kecil, tanda hubung, tanpa spasi, tanpa angka acak.

| Awalan | Arti | Contoh |
|---|---|---|
| `layer-` | bagian tampilan | `layer-body`, `layer-hair-front` |
| `joint-` | titik/grup sendi | `joint-shoulder-left` |
| `face-` | variasi wajah | `face-mouth-open`, `face-eyes-blink` |
| `fx-` | efek dekoratif | `fx-spark-1` |
| `bg-` | latar | `bg-hill-far` |

Aturan:
- `id` unik di dalam berkas dan **stabil antar versi** (spec merujuknya).
- Bagian yang bergerak berbeda wajib punya grup sendiri.
- Urutan dokumen = urutan tumpuk (z-order); jelaskan di katalog bila rumit.
- Titik pivot disimpan sebagai `data-pivot="x y"` dalam koordinat viewBox.

## 5. Warna dari token

- Isi dan kontur memakai **token warna**, bukan hex. Pipeline mengganti hex yang dikenal dengan variabel token, mis. `fill="var(--navy900)"` atau setara yang didukung komponen.
- Hex di luar palet **ditandai**: dipetakan ke token terdekat atau ditolak (keputusan Art Director). Dilarang meloloskan warna di luar palet diam-diam.
- Tanpa gradien, pola, filter, dan `opacity` kecuali ditetapkan eksplisit (mis. efek latar).
- **Ikon dan objek putih wajib berkontur `navy900`** (`icon.fill` = `white`, `icon.stroke` = `navy900`); putih tanpa kontur hilang di atas kuning (`STYLE_GUIDE.md` bagian 4).
- Kontur memakai ketebalan token (`stroke.main` / `stroke.detail`); `stroke-linecap` dan `stroke-linejoin` = `round`.

## 6. Teks menjadi path

- Teks statis di dalam SVG aset **diubah menjadi path** agar tidak bergantung font.
- Teks yang berubah/bergerak tidak ditaruh dalam aset; dibuat sebagai teks React dengan font token.
- Aset yang mengandung teks bahasa tertentu ditandai di manifes (`containsText: true`, bahasa).

## 7. Keamanan (SVG dari luar)

Hapus dan tolak:
- elemen `<script>`, atribut `on*` (`onclick`, `onload`, ...),
- `<foreignObject>`,
- referensi eksternal (`href`/`xlink:href`/`url()` ke `http(s):`, `data:` yang mencurigakan),
- `<use>` ke berkas luar, `@import`, entitas XML eksternal.

Berkas yang gagal pembersihan → status `rejected` di manifes dengan alasan.

## 8. Batas ukuran dan kompleksitas

| Metrik | Batas (draft) |
|---|---|
| Ukuran berkas setelah SVGO | ≤ 50 KB (ikon ≤ 5 KB; karakter rig ≤ 150 KB) |
| Jumlah elemen `path`/bentuk per aset | ≤ 300 (karakter ≤ 600) |
| Jumlah titik per path | mengikuti hasil SVGO; path > 2.000 titik ditandai |
| Kedalaman nest grup | ≤ 6 |

Melebihi batas → sederhanakan atau pecah menjadi beberapa aset. Pengecualian dicatat di manifes (`sizeException`).

## 9. Pembersihan (urutan skill "bersihkan SVG")

1. Parse dan validasi XML.
2. Hapus elemen/atribut berbahaya dan metadata (bagian 7).
3. Jalankan SVGO dengan konfigurasi proyek, **dengan opsi yang mempertahankan `id` dan `viewBox`** (jangan biarkan SVGO mengubah/menghapus id layer).
4. Normalkan `viewBox` (bagian 3).
5. Ubah teks menjadi path (bagian 6).
6. Petakan warna ke token (bagian 5).
7. Beri `id` per bagian bergerak dan pivot (bagian 4).
8. Periksa batas (bagian 8) dan hitung hash berkas.
9. Render still uji (latar `sun500` dan `white`) untuk pemeriksaan visual.
10. Tulis ke `assets.json`: status `approved` / `needs-review` / `rejected`.

## 10. Rig karakter (ditunda: pilot edukasi tanpa rig, D-028; berlaku setelah D-024)

- Satu `viewBox` untuk semua bagian; sendi berurutan hierarkis (badan → lengan atas → lengan bawah → tangan).
- Variasi (mulut, mata, pose tangan) berupa grup `face-*` atau `pose-*` yang ditampilkan/disembunyikan dari spec, tidak digambar ulang.
- Dokumentasikan di `COMPONENT_CATALOG.md`: daftar sendi, pivot, rentang rotasi aman, set ekspresi.
- Uji rentang gerak: sendi tidak boleh membuat bagian terpisah dari badan pada rentang aman.

## 11. Daftar periksa Lapis 1 untuk SVG

- [ ] `viewBox` ada dan sesuai kategori
- [ ] Tidak ada elemen/atribut terlarang (bagian 7)
- [ ] Semua warna dari token atau dipetakan
- [ ] `id` mengikuti format dan unik
- [ ] Ukuran dan jumlah elemen dalam batas
- [ ] Tidak ada teks hidup di dalam aset
- [ ] Still uji terbaca di latar kuning (`sun500`) dan putih
