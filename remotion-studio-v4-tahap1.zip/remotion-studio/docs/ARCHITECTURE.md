# ARCHITECTURE.md

> Struktur repo, alur data dari brief sampai MP4, dan peta komponen. Dimuat oleh agen pada tahap Spec, Build, dan Render.

## 1. Gambaran besar

```
brief.md ─► script.md ─► storyboard.md ─► audio ─► scenes/*.json ─► assets ─► build ─► QA ─► MP4
   [1]         [2]          [3]*           [4]        [5]            [6]       [7]     [8]    [9]*
                                  * = persetujuan manusia (storyboard, style frame, hasil akhir)
```

Prinsip: **data mengalir satu arah**. Tiap tahap hanya membaca keluaran tahap sebelumnya dan menulis keluarannya sendiri. Tahap tidak boleh mengubah keluaran tahap sebelumnya; bila perlu, kembalikan ke tahap pemiliknya.

## 2. Struktur repositori

```
/
├── AGENTS.md  CLAUDE.md  PROJECT.md  TASKS.md  DECISIONS.md  LESSONS.md
├── docs/                    # aturan teknis (STYLE_GUIDE, MOTION_SYSTEM, SIMPLE_AND_FUN, ...)
├── genres/                  # EDUCATION.md, ADVERTISING.md, ENTERTAINMENT.md
├── templates/               # BRIEF, SCRIPT, STORYBOARD, SHOTLIST, SCENE_SPEC
├── agents/                  # satu berkas per peran
├── skills/                  # skill proyek (SKILL.md per tugas berulang)
├── golden/                  # still referensi untuk deteksi regresi
├── packages/
│   ├── tokens/              # warna, tipografi, spacing, waktu, easing, spring
│   ├── schemas/             # schema Zod untuk spec adegan, brief, manifes
│   ├── components/          # pustaka komponen (primitif, senyawa, gerak, templat adegan)
│   └── assets-tools/        # skrip pipeline aset (unduh, cek lisensi, SVGO, normalisasi)
├── apps/
│   └── studio/              # proyek Remotion: komposisi, Root, entri render
├── projects/
│   └── <slug-video>/        # satu folder per video
│       ├── brief.md  script.md  storyboard.md  shotlist.md  seeds.md
│       ├── audio/           # narasi, musik, penanda waktu per kata, penanda ketukan
│       ├── scenes/          # 01-hook.json, 02-problem.json, ...
│       ├── assets.json      # aset terpilih untuk video ini
│       ├── qa/              # laporan, frame kunci, contact sheet
│       └── out/             # MP4, varian format, caption
├── assets/
│   ├── library/             # aset yang sudah dibersihkan + indeks pencarian
│   └── assets.json          # manifes global (mesin-baca)
└── .agents/skills/          # skill resmi Remotion (.claude/skills = symlink)
```

Aturan ketergantungan paket (satu arah, dicek lint):
`tokens` ← `schemas` ← `components` ← `apps/studio`. `tokens` tidak boleh mengimpor apa pun dari proyek.

## 3. Pipeline sembilan tahap

| # | Tahap | Pemilik | Masukan | Keluaran | Gerbang (harus lolos) |
|---|---|---|---|---|---|
| 1 | Brief | Sutradara | Permintaan manusia | `brief.md` | Lengkap: tujuan, audiens, genre, durasi, format, klaim bersumber. Tidak ambigu |
| 2 | Skrip | Penulis Skrip | `brief.md` | `script.md` + penanda waktu | Sesuai durasi; satu pesan inti; struktur sesuai genre |
| 3 | Storyboard | Sutradara + Art Director | `script.md` | `storyboard.md`, `shotlist.md` | **Persetujuan manusia** |
| 4 | Audio | Audio Producer | `script.md` | Narasi, musik, penanda per kata, penanda ketukan | **Panjang final terkunci** (frame tidak berubah lagi) |
| 5 | Spec adegan | Motion Designer | Storyboard + audio | `scenes/*.json` | Lolos validasi schema |
| 6 | Aset | Asset Curator | Spec (daftar kebutuhan aset) | Aset di `assets.json` proyek | Lisensi lolos; status `approved` |
| 7 | Build | Motion Designer | Spec + aset | Komposisi Remotion | Typecheck + lint lolos; **style frame disetujui manusia** (adegan pertama) |
| 8 | Verifikasi | QA Reviewer | Build | `qa/` laporan + skor rubrik | Skor di atas ambang; tidak ada kegagalan Lapis 1 |
| 9 | Render & ekspor | Motion Designer | Build lolos QA | MP4, varian format, caption | Pemeriksaan teknis akhir + **persetujuan manusia** |

**Gerbang gagal** → kembali ke tahap pemilik dengan daftar masalah spesifik. Hitung putaran; maksimal 3 per adegan (`DECISIONS.md` D-005).

**Penguncian audio (tahap 4)**: setelah terkunci, `calculateMetadata` membaca durasi dari audio. Mengubah audio setelah itu berarti mengulang dari tahap 5 untuk adegan terdampak.

## 4. Kontrak data antartahap

Kontrak ditulis sebagai schema di `packages/schemas/` dan didokumentasikan di `templates/SCENE_SPEC.md`. Ringkasan:

| Kontrak | Dibuat oleh | Dibaca oleh | Berisi |
|---|---|---|---|
| `brief` | Sutradara | semua | genre, audiens, durasi, format, `viewing`, pola hook, pesan inti, klaim + sumber, merek |
| `timing` | Audio Producer | Motion Designer, QA | penanda per kata, ketukan, durasi total (frame) |
| `scene` | Motion Designer | komponen, QA | durasi, tata letak, elemen, koreografi, kamera, teks, referensi audio |
| `asset manifest` | Asset Curator | Motion Designer, QA | sumber, URL, lisensi, penulis, atribusi, hash, status |
| `qa report` | QA Reviewer | Sutradara, manusia | skor per dimensi, daftar perbaikan spesifik, putaran ke-n |

Contoh kerangka spec adegan (bentuk final ditetapkan di M2):

```json
{
  "id": "02-problem",
  "schemaVersion": "1.0.0",
  "genre": "education",
  "durationFrames": 180,
  "layout": "split-left-focus",
  "background": "primary",
  "recipe": "terang-klasik",
  "motif": "rays",
  "camera": { "move": "push-in", "from": 1.0, "to": 1.08, "ease": "easeInOut" },
  "audio": { "narrationCue": "w_012", "beatSnap": true },
  "elements": [
    { "id": "hero", "component": "Blobby", "role": "hero", "priority": "must", "pose": "point" },
    { "id": "title", "component": "KineticTitle", "text": "Kenapa air laut asin?", "priority": "must", "enterAt": 6, "motion": "pop" }
  ],
  "choreography": [
    { "target": "hero", "motion": "slideIn", "at": 0, "duration": "base", "ease": "easeOut" },
    { "target": "title", "motion": "pop", "at": "after:hero+3", "spring": "snappy" }
  ]
}
```

Nilai `duration`, `ease`, `spring`, `background`, `motif` adalah **nama token**, bukan angka atau hex. `priority` menentukan elemen mana yang dibuang saat menurunkan ke 9:16 (`STYLE_GUIDE.md` bagian 8). Durasi adegan mengikuti kalimat narasi (D-017).

## 5. Pustaka komponen: empat tingkat

| Tingkat | Isi | Aturan |
|---|---|---|
| 1. Primitif | bentuk, garis yang digambar bertahap, teks, lapisan, wadah tata letak | Tidak tahu genre. Hanya menerima props bertoken |
| 2. Senyawa | karakter berlapis (rig SVG bersendi), kartu, grafik data, ikon beranimasi, caption | Tersusun dari primitif |
| 3. Gerak siap pakai | pop, slide, wipe, morph, counter, kinetic type, parallax, shake kecil | Membaca token waktu dan easing; murni fungsi dari `frame` |
| 4. Templat adegan | hook, penjelasan bertahap, perbandingan, demo produk, CTA, punchline | Dikelompokkan per genre; menerima spec, mengembalikan adegan |

Prosedur komponen baru: **usulan** (di `TASKS.md`, jelaskan kenapa komponen ada tidak cukup) → **implementasi + tes** (still dan, bila bergerak, contact sheet) → **golden still** disimpan → **masuk `COMPONENT_CATALOG.md`** (nama, props, contoh, batasan). Tanpa tahap terakhir, komponen dianggap belum ada.

## 6. Alur render

1. **Pratinjau**: `apps/studio` (Remotion Studio) untuk melihat komposisi.
2. **Still untuk QA**: render frame kunci (awal, puncak, akhir tiap adegan) ke `projects/<slug>/qa/`.
3. **Render lokal**: konkurensi diatur lewat konfigurasi; codec default H.264.
4. **Varian format**: satu spec, tiga komposisi (16:9, 9:16, 1:1) dengan aturan tata letak per rasio. Tidak ada adegan yang digambar ulang manual per rasio.
5. **Batch/awan**: opsi render awan (Lambda) untuk batch di M8. Cache aset dan hasil analisis audio.
6. **Ekspor**: MP4 + berkas caption + laporan QA + `manifest` versi (versi komponen, token, schema, aset).

## 7. Determinisme dan versi

- Render ulang dari spec + versi yang sama harus menghasilkan video yang **sama persis**. Larangan nilai acak bebas dan waktu dinding ada di `REMOTION_RULES.md`.
- Setiap proyek menyimpan `versions.lock.json`: versi Remotion, `tokens`, `schemas`, `components`, hash `assets.json`.
- Perubahan schema: naikkan `schemaVersion`, catat di `SCHEMA_CHANGELOG.md`, sediakan migrasi untuk spec lama.

## 8. CI

| Langkah | Gagal jika |
|---|---|
| Typecheck | ada galat tipe |
| Lint (termasuk aturan Remotion + aturan proyek) | ada pelanggaran |
| Tes schema | spec contoh tidak valid |
| Render still + banding dengan `golden/` | selisih piksel di atas toleransi tanpa persetujuan |
| Laporan QA Lapis 1 | ada kegagalan mekanis |
| Audit aset (terjadwal) | lisensi sumber berubah/hilang |

## 9. Anggaran dan biaya

Catat per video: token per tahap, waktu render, jumlah putaran perbaikan. Data masuk `COST_BUDGET.md`. Tahap yang paling boros menjadi kandidat otomasi atau penyederhanaan.
