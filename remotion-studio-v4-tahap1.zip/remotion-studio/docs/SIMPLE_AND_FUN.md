# SIMPLE_AND_FUN.md

> Cara membuat video **simpel dan seru**, tidak membosankan, tanpa menjadi ramai. Dibaca Penulis Skrip, Sutradara, Art Director, dan Motion Designer sebelum menulis skrip, storyboard, dan spec.
> Status: **v2 (D-030)**. Semua angka adalah **titik awal**, dikalibrasi di pilot edukasi. Aturan teknis tetap di `MOTION_SYSTEM.md` dan `STYLE_GUIDE.md`; dokumen ini tidak menggantinya.

## 1. Definisi

- **Simpel** = satu ide per video, satu hero per adegan, sedikit kata, bentuk dasar.
- **Seru** = tiap beberapa detik ada kejutan kecil yang **bermakna**, dan gerak punya rasa (antisipasi, overshoot, pantulan), bukan sekadar fade.
- **Seru bukan ramai.** Kejutan yang tidak membantu pesan dihapus.

## 2. Resep satu adegan: tiga ketukan

```
[ Setup ]  →  [ HERO BEAT ]  →  [ Payoff + tahan ]
 latar & konteks   satu momen utama,     teks terbaca; gerak kecil
 masuk cepat       jatuh di kata/ketukan  menjaga adegan hidup
 (~20%)            (~20%)                 (~60%)
```

- Setup menjawab "sekarang kita di mana?". Hero beat menjawab "lihat ini!". Payoff memberi waktu paham.
- **Tahan tidak berarti diam**: teks yang sedang dibaca tidak bergerak, tetapi latar boleh `breathe` pelan dan satu aksi sekunder kecil boleh jalan (`MOTION_SYSTEM.md` bagian 6).

## 3. Hook 3 detik pertama

Tiga detik pertama harus bergerak dan memancing rasa ingin tahu. Pesan inti dan hook tetap terbaca **tanpa suara** (D-020). Pola hook (pilih satu, tulis di `brief.md`):

| Pola | Bentuk | Visual |
|---|---|---|
| Pertanyaan | "Kenapa ...?" satu kalimat pendek | kinetic type besar di kartu putih, latar `bg.primary` |
| Angka | satu angka besar yang relevan dan **bersumber** | `counter` naik, latar `bg.energy` |
| Salah kaprah | benda/pernyataan yang "kelihatan benar" lalu dibalik | dua kartu, satu ditandai silang lalu diganti |
| Perbandingan | dua hal berdampingan, satu kejutan | panel terbagi |
| Teka-teki | benda ditutup, dibuka di kata kunci | `wipe` blok warna |

Hook tidak boleh mengarang fakta. Angka dan klaim wajib punya sumber di brief (`AGENTS.md` aturan 10).

## 4. Kosakata gerak seru (dipilih dari pustaka M3)

| Efek | Kapan dipakai | Catatan |
|---|---|---|
| `pop` dengan overshoot | kemunculan hero | satu kali per adegan |
| Stiker pop | ikon pendukung masuk berurutan (`stagger`) | ikon putih berkontur navy + bayangan blok |
| `wipe` blok warna | pindah bagian | blok kuning/putih; navy hanya sebagai pita tipis |
| `kineticType` | judul pendek, kata kunci | per kata; spring `calm`/`snappy`, bukan `bouncy` |
| `drawOn` | garis bawah, panah, lingkaran penekan | terasa "digambar tangan" |
| `counter` | angka | berhenti dengan sedikit overshoot |
| Shape acting (`Blobby`) | penjelas yang butuh "rasa" | squash dan stretch, kedip, menunjuk; tanpa rig |
| `pulseToBeat` | bila ada musik berirama | selaras ketukan |
| Percikan kecil (`sparkle`) | penekanan setelah hero | 3 sampai 5 bentuk, `dur.fast`, kontras rendah |

## 5. Anggaran seru (agar tidak berlebihan)

Titik awal untuk edukasi:

| Hal | Batas |
|---|---|
| Kejutan kecil ("delight") per adegan | ≤ 1, selalu di bawah hero |
| Momen wow (hero beat dengan overshoot) | ≥ 1 per 10 detik video |
| Jeda tanpa perubahan visual | ≤ 3 detik |
| Shake kamera | hanya hiburan; ≤ 1 per 15 detik |
| Adegan dengan resep warna dan templat yang sama berurutan | 0 |

## 6. Daftar anti-bosan

- Tidak ada adegan edukasi > 8 detik tanpa perubahan visual.
- Tidak ada layar berisi paragraf atau daftar poin ala slide. Satu kalimat, satu visual.
- Satu **metafora visual** per konsep (benda yang bisa dilihat), bukan label saja.
- Ganti resep warna dan latar antar adegan (`STYLE_GUIDE.md` bagian 4); ganti tata letak minimal tiap dua adegan.
- Arah masuk elemen bermakna, bukan acak (`MOTION_SYSTEM.md` bagian 6).
- Bagian terakhir selalu menutup dengan satu rangkuman dan satu ajakan jelas.

## 7. Kerangka edukasi 30 sampai 45 detik (pilot)

Contoh 36 detik, 8 adegan. Durasi di tabel adalah titik awal; batas sebenarnya mengikuti kalimat narasi (D-017).

| # | Adegan | Detik | Resep warna | Hero beat |
|---|---|---|---|---|
| 1 | Hook | 3 | Terang klasik | pertanyaan pop di kartu putih |
| 2 | Masalah | 5 | Hangat penekanan | benda "bermasalah" masuk dengan antisipasi |
| 3 | Ide inti | 6 | Energi | konsep muncul besar; `motif.rays` di belakangnya |
| 4 | Langkah 1 | 4 | Krim tenang | ikon pertama pop, diagram mulai dibangun |
| 5 | Langkah 2 | 4 | Terang klasik | elemen kedua ditambah dan disorot |
| 6 | Langkah 3 | 4 | Panel terbagi | hasil muncul di panel putih |
| 7 | Contoh | 5 | Krim tenang | analogi visual satu benda |
| 8 | Rangkuman + CTA | 5 | Energi | satu kalimat rangkuman, lalu ajakan |

Total 36 detik; ritme ≈ 0,6 sampai 1,2 perubahan visual per detik (`MOTION_SYSTEM.md` bagian 9).

## 8. Cara menilai "seru"

Kita ukur, bukan merasa:

| Ukur | Cara | Titik awal |
|---|---|---|
| Peta ritme | skrip dari spec: perubahan visual per detik, momen wow per 10 detik, jeda terpanjang | dalam rentang genre; jeda ≤ 3 dtk |
| Penonton uji | 5 orang menonton, ditanya: "bagian mana yang ingin kamu tonton lagi?" dan "di mana kamu mulai bosan?" | minimal 3 dari 5 menyebut bagian hero yang sama; tidak ada titik bosan yang sama pada ≥ 3 orang |
| Pemahaman | 3 pertanyaan pemahaman setelah menonton | ≥ 80% benar |
| Tanpa suara | tonton bisu, tulis pesannya | ≥ 4 dari 5 sama dengan `brief.md` |

Bila skor rubrik lolos tetapi penonton bosan, **manusia menang** dan kasusnya dicatat di `LESSONS.md` (D-029). Kriteria "daya tarik" ditambahkan ke `RUBRIC.md` saat dibuat (Batch 3).
