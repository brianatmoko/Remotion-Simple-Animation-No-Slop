# MOTION_SYSTEM.md

> Sistem gerak: token waktu, easing, spring, stagger, koreografi, kamera, transisi, ritme, dan penerapan 12 prinsip animasi.
> Status: **DRAFT**. Angka dikalibrasi di M3 (pustaka gerak) dan dikunci setelah adegan uji lolos. Semua waktu dalam **frame pada 30 fps** (`DECISIONS.md` D-007). Bila fps berubah, hitung ulang di satu tempat: `packages/tokens/motion.ts`.

## 1. Aturan emas

1. **Gerak punya alasan.** Setiap gerakan menjawab: apa yang ingin diperhatikan penonton sekarang?
2. **Satu hero beat per adegan.** Satu momen utama (kemunculan hero, punchline, CTA). Gerak lain mendukung, lebih kecil dan lebih sunyi.
3. **Tidak ada gerak linier tanpa alasan.** Linier hanya untuk rotasi tetap, loop, dan bilah progres.
4. **Semua dari token.** Durasi, easing, spring, stagger dipanggil dengan nama, tidak dengan angka.
5. **Seru tapi simpel.** Gerak punya rasa (antisipasi, overshoot) tetapi tetap sedikit; lihat `SIMPLE_AND_FUN.md`.
6. **Audio memimpin.** Peristiwa gerak penting jatuh pada penanda audio (ketukan/kata) dengan toleransi ±1 frame.

## 2. Token durasi

| Token | Frame | Detik | Dipakai |
|---|---|---|---|
| `dur.instant` | 3 | 0,10 | kedip, pergantian ekspresi |
| `dur.fast` | 6 | 0,20 | detail kecil, hover-like, penekanan |
| `dur.base` | 12 | 0,40 | masuk/keluar elemen standar |
| `dur.slow` | 20 | 0,67 | elemen besar, adegan tenang |
| `dur.epic` | 36 | 1,20 | momen dramatis, pembukaan besar |

Elemen **keluar** lebih cepat dari saat masuk (±70% durasi masuk).

## 3. Token easing

Dalam Remotion diwujudkan dengan kurva bezier (`Easing.bezier`). Nilai draft:

| Token | Kurva bezier (x1, y1, x2, y2) | Sifat | Dipakai |
|---|---|---|---|
| `ease.out` | 0.16, 1, 0.30, 1 | cepat di awal, mendarat lembut | masuk elemen (default) |
| `ease.in` | 0.70, 0, 0.84, 0 | lambat di awal, cepat di akhir | keluar elemen |
| `ease.inOut` | 0.65, 0, 0.35, 1 | halus di kedua ujung | perpindahan posisi, kamera |
| `ease.back` | 0.34, 1.56, 0.64, 1 | melewati target lalu kembali | pop, penekanan ceria |
| `ease.anticipate` | 0.36, 0, 0.66, -0.56 | mundur dulu sebelum maju | persiapan gerak besar |
| `ease.linear` | n/a | konstan | rotasi, loop, progres |

## 4. Token spring

Spring dipakai untuk gerak organik (skala, posisi, rotasi) dan selalu bersama `fps`.

| Token | damping | stiffness | mass | Sifat |
|---|---|---|---|---|
| `spring.calm` | 26 | 120 | 1 | lembut, nyaris tanpa pantulan (edukasi) |
| `spring.snappy` | 20 | 200 | 0.6 | cepat, sedikit pantulan (default iklan) |
| `spring.bouncy` | 10 | 180 | 0.7 | pantulan jelas (hiburan, pop karakter) |
| `spring.heavy` | 30 | 90 | 1.6 | objek berat, kamera |

Aturan: spring dengan pantulan (`bouncy`) tidak dipakai untuk teks yang harus dibaca; teks memakai `calm`/`snappy` atau `ease.out`.

## 5. Stagger dan overlap

| Token | Jarak antar elemen | Dipakai |
|---|---|---|
| `stagger.tight` | 2 frame | kelompok kecil dan cepat (iklan) |
| `stagger.base` | 3 frame | standar |
| `stagger.calm` | 4 frame | edukasi, diagram bertahap |

- Elemen dalam satu kelompok **tumpang tindih**: elemen berikutnya mulai sebelum yang sebelumnya selesai (jeda 2 sampai 4 frame, bukan menunggu selesai).
- Urutan stagger mengikuti urutan baca/penting (kiri ke kanan, atas ke bawah) atau menjauh dari hero.
- Kelompok lebih dari 8 elemen: bagi menjadi dua gelombang.

## 6. Koreografi adegan

Struktur satu adegan:

```
[ pra-roll ][ masuk latar ][ HERO BEAT ][ elemen pendukung ][ tahan ][ keluar ]
   0-6f        0-12f          pada ketukan     stagger          baca     70% masuk
```

- **Hero beat** ditandai di spec (`role: "hero"`) dan dijatuhkan pada penanda ketukan atau kata kunci.
- **Waktu tahan (hold)**: teks harus tampil cukup lama untuk dibaca.
  - Minimum: `max(30 frame, jumlah_kata × 10 frame)` untuk edukasi; `× 8` untuk iklan; `× 8` untuk hiburan.
  - Teks yang masih bergerak tidak dihitung sebagai "tahan".
- **Jangan menaruh dua hero beat dalam jarak < 18 frame** (0,6 detik).
- **Arah masuk konsisten**: elemen masuk dari arah yang bermakna (konten baru dari kanan/bawah, kembali/mundur dari kiri, penekanan = skala tanpa pergeseran). Jangan acak.

## 7. Penerapan 12 prinsip animasi

| # | Prinsip | Penerapan di sistem ini |
|---|---|---|
| 1 | Squash & stretch | `ease.back`/`spring.bouncy` + skala non-uniform kecil (±8%) pada pop karakter dan objek hidup. Tidak pada teks |
| 2 | Anticipation | `ease.anticipate` atau mundur 3-6 frame sebelum gerak besar; wajib untuk hero beat besar |
| 3 | Staging | Satu hero per frame; kamera dan kontras mengarahkan mata (`STYLE_GUIDE.md` bagian 7) |
| 4 | Straight ahead / pose to pose | Pose kunci di spec (pose-to-pose); gerak sekunder memakai noise berbasis seed (straight-ahead terkendali) |
| 5 | Follow through & overlapping action | Bagian pelengkap (rambut, lengan, aksesori) bergerak 2-4 frame lebih lambat dari badan; overlap lewat stagger |
| 6 | Slow in / slow out | Default `ease.out`/`ease.inOut`; linier dilarang kecuali pengecualian aturan emas 3 |
| 7 | Arcs | Gerak sendi karakter dan objek melempar mengikuti busur (rotasi sendi, bukan translasi lurus) |
| 8 | Secondary action | Aksi pendukung (kedip, ikon kecil, partikel) di bawah hero; tidak boleh menarik perhatian dari hero |
| 9 | Timing | Token durasi + ritme per genre (bagian 9); jumlah frame menyampaikan bobot dan emosi |
| 10 | Exaggeration | Bold vector menuntut: pose, ekspresi, skala dilebih-lebihkan (terutama hiburan) |
| 11 | Solid drawing | Bentuk (`Blobby`, rig bila sudah ada) dengan volume konsisten; siluet terbaca; bayangan blok memberi bobot |
| 12 | Appeal | Bentuk sederhana, ramah, konsisten; diuji lewat style frame |

Skill review (`VISUAL_REVIEW_PROMPT.md`) memeriksa penerapan prinsip yang relevan per adegan dan menuliskan perbaikan spesifik.

## 8. Kamera dan transisi (ringkasan; rinci di `CAMERA_RULES.md` dan `TRANSITIONS.md`)

**Kamera virtual**: zoom dan pan pada seluruh adegan SVG lewat satu komponen `Camera` yang membaca spec.
- Pembingkaian: aturan sepertiga, ruang kepala (headroom), ruang arah pandang.
- Gerak kamera: `ease.inOut` atau `spring.heavy`; **tidak** dimulai dan berhenti mendadak.
- Skala kamera dalam rentang 1.0 sampai 1.25 (di atasnya SVG mulai terlihat kasar atau elemen terpotong); pengecualian dicatat.
- Hanya satu gerak kamera utama per adegan.
- Shake kecil hanya untuk hiburan/penekanan: amplitudo ≤ 8 px, ≤ 12 frame, berbasis seed.

**Transisi**: daftar kecil dengan makna, dilarang acak.

| Transisi | Makna | Genre utama |
|---|---|---|
| `wipe` | pindah topik/bagian; blok kuning/putih, navy hanya pita tipis | semua |
| `push` (zoom) | masuk ke fokus/detail | edukasi, iklan |
| `match-cut` | menyambung bentuk atau gerak antar adegan | iklan, hiburan |
| `cut` (tanpa efek) | momen cepat, punchline, ketukan | iklan, hiburan |
| `fade-dip` | jeda, akhir bagian, penutup | edukasi |

Durasi transisi: 8 sampai 15 frame; `cut` = 0. Transisi jatuh pada ketukan bila ada musik.

## 9. Profil ritme per genre

"Perubahan visual" = elemen baru masuk, pergantian adegan, atau gerak kamera utama.

| Genre | Perubahan visual per detik | Durasi adegan tipikal | Spring/ease default | Transisi dominan |
|---|---|---|---|---|
| Edukasi | 0,6 sampai 1,2 | 4 sampai 8 detik | `spring.calm`, `ease.out` | `wipe`, `fade-dip`, `push` |
| Iklan | 1,5 sampai 3,0 | 1,5 sampai 4 detik | `spring.snappy`, `ease.out` | `cut`, `match-cut`, `push` |
| Hiburan | 1,0 sampai 3,0 (berirama, ada jeda komedi) | 1 sampai 6 detik | `spring.bouncy`, `ease.back` | `cut`, `match-cut` |

Rentang ini acuan awal yang dikalibrasi di M7 dengan data pilot. QA memeriksa apakah ritme video berada dalam rentang genre.

## 10. Keselamatan dan aksesibilitas gerak

- **Tidak lebih dari 3 kilatan per detik.** Kilatan = perubahan terang/gelap besar dan cepat pada area luas (pergantian latar penuh, strobo). Pergantian antar langkah kuning (mis. `sun500` ke `sun100`) ikut dihitung. QA Lapis 1 mengukurnya dari frame berurutan.
- Hindari pola garis/kotak berkontras tinggi yang berkedip atau bergetar pada area luas.
- Gerak kamera besar dan berulang dibatasi; hindari goyangan terus-menerus.
- Teks penting tidak boleh bergerak saat dibaca (hold, bagian 6).
- Detail di `ACCESSIBILITY.md`.

## 11. Pustaka gerak siap pakai (target M3: 15)

`lipSync` ditunda sampai uji karakter AI lulus (D-024). Shape acting (squash dan stretch, kedip) memakai komponen `Blobby` di M1.

Semua adalah fungsi dari `frame` dan hanya menerima token.

| Gerak | Efek | Token default |
|---|---|---|
| `pop` | skala 0 → 1 dengan pantulan | `spring.snappy` |
| `slideIn / slideOut` | geser dari tepi/jarak tertentu | `ease.out` / `ease.in` |
| `fadeUp` | muncul sambil naik sedikit | `ease.out`, `dur.base` |
| `wipe` | pengungkapan dengan bentuk penutup | `ease.inOut` |
| `morph` | bentuk berubah ke bentuk lain | `ease.inOut`, `dur.slow` |
| `counter` | angka naik/turun | `ease.out` |
| `kineticType` | teks muncul per kata/huruf | `stagger.*`, `spring.*` |
| `drawOn` | garis digambar bertahap | `ease.inOut` |
| `parallax` | lapisan latar bergerak beda kecepatan | `ease.linear`/`ease.inOut` |
| `shake` | getar kecil (seed tetap) | peluruhan cepat |
| `breathe` | skala kecil berulang (idle karakter) | `ease.inOut`, loop |
| `blink` | kedip mata | `dur.instant` |
| `sparkle` | percikan 3 sampai 5 bentuk kecil setelah hero | `dur.fast`, `ease.out` |
| `pulseToBeat` | berdenyut mengikuti ketukan/volume | dari `timing` |
| `cameraMove` | zoom/pan | `ease.inOut` / `spring.heavy` |

## 12. Bentuk berkas token (acuan)

```ts
// packages/tokens/motion.ts  (fps = 30)
export const FPS = 30;
export const DUR = { instant: 3, fast: 6, base: 12, slow: 20, epic: 36 } as const;
export const STAGGER = { tight: 2, base: 3, calm: 4 } as const;
export const SPRING = {
  calm:   { damping: 26, stiffness: 120, mass: 1 },
  snappy: { damping: 20, stiffness: 200, mass: 0.6 },
  bouncy: { damping: 10, stiffness: 180, mass: 0.7 },
  heavy:  { damping: 30, stiffness: 90,  mass: 1.6 },
} as const;
// EASE dibuat dengan Easing.bezier(...) dari remotion, nilai di tabel bagian 3.
```

## 13. Kriteria lulus M3

- 15 gerak siap pakai, masing-masing punya still/contact sheet dan masuk `COMPONENT_CATALOG.md`.
- Adegan uji 10 detik: skor dimensi "Gerak dan timing" di atas ambang `RUBRIC.md`.
- Tidak ada angka frame/easing mentah di kode adegan (lint).
- Pengecekan kilatan dan hold teks otomatis berfungsi.
